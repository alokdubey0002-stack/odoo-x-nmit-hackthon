"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
} from "recharts"
import { TrendingUp, TrendingDown, Users, Clock, Target, BarChart3, PieChartIcon, Activity } from "lucide-react"

interface ProgressVisualizationProps {
  onBack: () => void
}

const projectProgressData = [
  { name: "Website Redesign", completed: 65, remaining: 35, tasks: 12, completedTasks: 8 },
  { name: "Mobile App", completed: 25, remaining: 75, tasks: 24, completedTasks: 6 },
  { name: "Marketing Campaign", completed: 90, remaining: 10, tasks: 8, completedTasks: 7 },
  { name: "User Research", completed: 100, remaining: 0, tasks: 6, completedTasks: 6 },
]

const teamPerformanceData = [
  { name: "Alice Johnson", tasksCompleted: 24, tasksInProgress: 3, efficiency: 92 },
  { name: "Bob Smith", tasksCompleted: 18, tasksInProgress: 5, efficiency: 78 },
  { name: "Carol Davis", tasksCompleted: 21, tasksInProgress: 2, efficiency: 88 },
  { name: "David Kim", tasksCompleted: 15, tasksInProgress: 4, efficiency: 85 },
]

const weeklyProgressData = [
  { week: "Week 1", completed: 12, planned: 15, efficiency: 80 },
  { week: "Week 2", completed: 18, planned: 20, efficiency: 90 },
  { week: "Week 3", completed: 22, planned: 25, efficiency: 88 },
  { week: "Week 4", completed: 28, planned: 30, efficiency: 93 },
  { week: "Week 5", completed: 25, planned: 28, efficiency: 89 },
  { week: "Week 6", completed: 32, planned: 35, efficiency: 91 },
]

const taskStatusData = [
  { name: "Completed", value: 45, color: "#10b981" },
  { name: "In Progress", value: 28, color: "#3b82f6" },
  { name: "Review", value: 12, color: "#8b5cf6" },
  { name: "Todo", value: 35, color: "#6b7280" },
]

const burndownData = [
  { day: "Day 1", ideal: 100, actual: 100 },
  { day: "Day 2", ideal: 90, actual: 95 },
  { day: "Day 3", ideal: 80, actual: 88 },
  { day: "Day 4", ideal: 70, actual: 82 },
  { day: "Day 5", ideal: 60, actual: 75 },
  { day: "Day 6", ideal: 50, actual: 68 },
  { day: "Day 7", ideal: 40, actual: 58 },
  { day: "Day 8", ideal: 30, actual: 45 },
  { day: "Day 9", ideal: 20, actual: 32 },
  { day: "Day 10", ideal: 10, actual: 18 },
  { day: "Day 11", ideal: 0, actual: 8 },
]

const resourceUtilizationData = [
  { resource: "Developers", allocated: 85, available: 15 },
  { resource: "Designers", allocated: 70, available: 30 },
  { resource: "QA Engineers", allocated: 60, available: 40 },
  { resource: "Project Managers", allocated: 90, available: 10 },
]

export function ProgressVisualization({ onBack }: ProgressVisualizationProps) {
  const [selectedTimeframe, setSelectedTimeframe] = useState("month")
  const [selectedProject, setSelectedProject] = useState("all")

  const totalTasks = taskStatusData.reduce((sum, item) => sum + item.value, 0)
  const completedTasks = taskStatusData.find((item) => item.name === "Completed")?.value || 0
  const completionRate = Math.round((completedTasks / totalTasks) * 100)

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="outline" onClick={onBack}>
                ← Back
              </Button>
              <div>
                <h1 className="text-xl font-bold">Progress Analytics</h1>
                <p className="text-sm text-muted-foreground">Comprehensive project and team performance insights</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="week">This Week</SelectItem>
                  <SelectItem value="month">This Month</SelectItem>
                  <SelectItem value="quarter">This Quarter</SelectItem>
                  <SelectItem value="year">This Year</SelectItem>
                </SelectContent>
              </Select>
              <Select value={selectedProject} onValueChange={setSelectedProject}>
                <SelectTrigger className="w-[160px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Projects</SelectItem>
                  <SelectItem value="website">Website Redesign</SelectItem>
                  <SelectItem value="mobile">Mobile App</SelectItem>
                  <SelectItem value="marketing">Marketing Campaign</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Overall Progress</p>
                  <p className="text-2xl font-bold">{completionRate}%</p>
                  <div className="flex items-center gap-1 mt-1">
                    <TrendingUp className="h-4 w-4 text-green-500" />
                    <span className="text-sm text-green-500">+5.2% from last week</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
                  <Target className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Team Velocity</p>
                  <p className="text-2xl font-bold">32</p>
                  <p className="text-sm text-muted-foreground">tasks/week</p>
                  <div className="flex items-center gap-1 mt-1">
                    <TrendingUp className="h-4 w-4 text-green-500" />
                    <span className="text-sm text-green-500">+12% efficiency</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 rounded-lg flex items-center justify-center">
                  <Activity className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Active Projects</p>
                  <p className="text-2xl font-bold">3</p>
                  <p className="text-sm text-muted-foreground">1 completed this month</p>
                  <div className="flex items-center gap-1 mt-1">
                    <Clock className="h-4 w-4 text-orange-500" />
                    <span className="text-sm text-orange-500">2 due this week</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/20 rounded-lg flex items-center justify-center">
                  <BarChart3 className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Resource Utilization</p>
                  <p className="text-2xl font-bold">76%</p>
                  <p className="text-sm text-muted-foreground">across all teams</p>
                  <div className="flex items-center gap-1 mt-1">
                    <TrendingDown className="h-4 w-4 text-red-500" />
                    <span className="text-sm text-red-500">-3% from optimal</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900/20 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="team">Team</TabsTrigger>
            <TabsTrigger value="burndown">Burndown</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <PieChartIcon className="h-5 w-5" />
                    Task Distribution
                  </CardTitle>
                  <CardDescription>Current status of all tasks across projects</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={taskStatusData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={120}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {taskStatusData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="grid grid-cols-2 gap-4 mt-4">
                    {taskStatusData.map((item) => (
                      <div key={item.name} className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                        <span className="text-sm font-medium">{item.name}</span>
                        <Badge variant="outline">{item.value}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Weekly Progress Trend
                  </CardTitle>
                  <CardDescription>Task completion vs planned over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={weeklyProgressData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="week" />
                        <YAxis />
                        <Tooltip />
                        <Area
                          type="monotone"
                          dataKey="planned"
                          stackId="1"
                          stroke="#e5e7eb"
                          fill="#e5e7eb"
                          name="Planned"
                        />
                        <Area
                          type="monotone"
                          dataKey="completed"
                          stackId="2"
                          stroke="#3b82f6"
                          fill="#3b82f6"
                          name="Completed"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="projects" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Project Progress Overview</CardTitle>
                <CardDescription>Completion status and task breakdown for all active projects</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={projectProgressData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="completed" fill="#10b981" name="Completed %" />
                      <Bar dataKey="remaining" fill="#e5e7eb" name="Remaining %" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="team" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Team Performance Metrics</CardTitle>
                <CardDescription>Individual team member productivity and efficiency ratings</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={teamPerformanceData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="tasksCompleted" fill="#3b82f6" name="Tasks Completed" />
                      <Bar dataKey="tasksInProgress" fill="#f59e0b" name="Tasks In Progress" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
                  {teamPerformanceData.map((member) => (
                    <Card key={member.name}>
                      <CardContent className="p-4">
                        <h4 className="font-semibold mb-2">{member.name}</h4>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span>Completed:</span>
                            <Badge variant="outline">{member.tasksCompleted}</Badge>
                          </div>
                          <div className="flex justify-between">
                            <span>In Progress:</span>
                            <Badge variant="outline">{member.tasksInProgress}</Badge>
                          </div>
                          <div className="flex justify-between">
                            <span>Efficiency:</span>
                            <Badge
                              className={
                                member.efficiency >= 85
                                  ? "bg-green-100 text-green-800"
                                  : "bg-yellow-100 text-yellow-800"
                              }
                            >
                              {member.efficiency}%
                            </Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="burndown" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Sprint Burndown Chart</CardTitle>
                <CardDescription>Ideal vs actual progress for current sprint</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={burndownData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="day" />
                      <YAxis />
                      <Tooltip />
                      <Line
                        type="monotone"
                        dataKey="ideal"
                        stroke="#e5e7eb"
                        strokeDasharray="5 5"
                        name="Ideal Progress"
                      />
                      <Line type="monotone" dataKey="actual" stroke="#3b82f6" strokeWidth={2} name="Actual Progress" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-4 p-4 bg-muted/50 rounded-lg">
                  <div className="flex items-center justify-between text-sm">
                    <div>
                      <span className="font-medium">Sprint Status:</span>
                      <Badge className="ml-2 bg-yellow-100 text-yellow-800">Behind Schedule</Badge>
                    </div>
                    <div>
                      <span className="font-medium">Estimated Completion:</span>
                      <span className="ml-2">2 days late</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="resources" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Resource Utilization</CardTitle>
                <CardDescription>Current allocation and availability across teams</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={resourceUtilizationData}
                      layout="horizontal"
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" domain={[0, 100]} />
                      <YAxis dataKey="resource" type="category" />
                      <Tooltip />
                      <Bar dataKey="allocated" fill="#3b82f6" name="Allocated %" />
                      <Bar dataKey="available" fill="#10b981" name="Available %" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                  {resourceUtilizationData.map((resource) => (
                    <Card key={resource.resource}>
                      <CardContent className="p-4">
                        <h4 className="font-semibold mb-2">{resource.resource}</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Allocated:</span>
                            <span className="font-medium">{resource.allocated}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${resource.allocated}%` }} />
                          </div>
                          <div className="flex justify-between text-sm">
                            <span>Available:</span>
                            <span className="font-medium text-green-600">{resource.available}%</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
