"use client"

import { useState } from "react"
import { useAuth } from "@/components/auth/auth-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  LogOut,
  Plus,
  Users,
  CheckSquare,
  MessageSquare,
  BarChart3,
  Zap,
  Calendar,
  Search,
  Grid,
  List,
  Settings,
  Eye,
  ClipboardList,
  UserCheck,
  Bell,
} from "lucide-react"
import { ProjectCreationModal } from "./project-creation-modal"
import { ProjectDetailModal } from "./project-detail-modal"
import { TaskManagement } from "@/components/tasks/task-management"
import { TeamManagement } from "@/components/team/team-management"
import { CommunicationHub } from "@/components/communication/communication-hub"
import { ProgressVisualization } from "@/components/analytics/progress-visualization"
import { NotificationCenter } from "@/components/notifications/notification-center"
import { ToastNotifications } from "@/components/notifications/toast-notifications"

interface Project {
  id: string
  name: string
  description: string
  status: "Planning" | "In Progress" | "Review" | "Completed" | "On Hold"
  priority: "Low" | "Medium" | "High" | "Critical"
  progress: number
  members: number
  tasks: number
  completedTasks: number
  dueDate: string
  createdDate: string
  category: "Development" | "Design" | "Marketing" | "Research" | "Operations"
  budget?: number
  owner: string
}

export function Dashboard() {
  const { user, logout } = useAuth()
  const [currentView, setCurrentView] = useState<"dashboard" | "tasks" | "team" | "communication" | "analytics">(
    "dashboard",
  )
  const [selectedProjectForTasks, setSelectedProjectForTasks] = useState<{ id: string; name: string } | null>(null)
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [priorityFilter, setPriorityFilter] = useState<string>("all")
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [selectedProject, setSelectedProject] = useState<Project | null>(null)
  const [showNotifications, setShowNotifications] = useState(false)
  const [notifications, setNotifications] = useState([
    {
      id: "1",
      type: "mention" as const,
      title: "You were mentioned",
      message: "Alice Johnson mentioned you in Website Redesign project discussion",
      timestamp: "2 minutes ago",
      read: false,
      priority: "high" as const,
      author: "Alice Johnson",
      avatar: "/placeholder.svg?height=32&width=32",
    },
    {
      id: "2",
      type: "assignment" as const,
      title: "New task assigned",
      message: "You have been assigned to 'Update homepage design' in Website Redesign",
      timestamp: "15 minutes ago",
      read: false,
      priority: "medium" as const,
      author: "Bob Smith",
      avatar: "/placeholder.svg?height=32&width=32",
    },
    {
      id: "3",
      type: "deadline" as const,
      title: "Deadline approaching",
      message: "Marketing Campaign project is due in 2 days",
      timestamp: "1 hour ago",
      read: false,
      priority: "high" as const,
    },
  ])
  const [toastNotifications, setToastNotifications] = useState<any[]>([])
  const [projects, setProjects] = useState<Project[]>([
    {
      id: "1",
      name: "Website Redesign",
      description: "Complete overhaul of company website with modern design and improved UX",
      status: "In Progress",
      priority: "High",
      progress: 65,
      members: 4,
      tasks: 12,
      completedTasks: 8,
      dueDate: "2024-02-15",
      createdDate: "2024-01-01",
      category: "Design",
      budget: 25000,
      owner: "Sarah Johnson",
    },
    {
      id: "2",
      name: "Mobile App Development",
      description: "Native iOS and Android application for customer engagement",
      status: "Planning",
      priority: "Critical",
      progress: 25,
      members: 6,
      tasks: 24,
      completedTasks: 6,
      dueDate: "2024-03-30",
      createdDate: "2024-01-10",
      category: "Development",
      budget: 50000,
      owner: "Mike Chen",
    },
    {
      id: "3",
      name: "Marketing Campaign",
      description: "Q1 product launch campaign across multiple channels",
      status: "Review",
      priority: "Medium",
      progress: 90,
      members: 3,
      tasks: 8,
      completedTasks: 7,
      dueDate: "2024-01-20",
      createdDate: "2023-12-15",
      category: "Marketing",
      budget: 15000,
      owner: "Lisa Park",
    },
    {
      id: "4",
      name: "User Research Study",
      description: "Comprehensive user behavior analysis and feedback collection",
      status: "Completed",
      priority: "Medium",
      progress: 100,
      members: 2,
      tasks: 6,
      completedTasks: 6,
      dueDate: "2024-01-05",
      createdDate: "2023-12-01",
      category: "Research",
      owner: "David Kim",
    },
  ])

  const filteredProjects = projects.filter((project) => {
    const matchesSearch =
      project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = statusFilter === "all" || project.status === statusFilter
    const matchesPriority = priorityFilter === "all" || project.priority === priorityFilter

    return matchesSearch && matchesStatus && matchesPriority
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "In Progress":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400"
      case "Planning":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400"
      case "Review":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400"
      case "Completed":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400"
      case "On Hold":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "Critical":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400"
      case "High":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400"
      case "Medium":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400"
      case "Low":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
    }
  }

  const stats = {
    activeProjects: projects.filter((p) => p.status === "In Progress" || p.status === "Planning").length,
    totalMembers: projects.reduce((sum, p) => sum + p.members, 0),
    completedTasks: projects.reduce((sum, p) => sum + p.completedTasks, 0),
    totalTasks: projects.reduce((sum, p) => sum + p.tasks, 0),
  }

  const handleCreateProject = (projectData: Omit<Project, "id" | "createdDate">) => {
    const newProject: Project = {
      ...projectData,
      id: Date.now().toString(),
      createdDate: new Date().toISOString().split("T")[0],
    }
    setProjects([...projects, newProject])
    setShowCreateModal(false)

    const toastId = Date.now().toString()
    setToastNotifications([
      ...toastNotifications,
      {
        id: toastId,
        type: "success",
        title: "Project Created",
        message: `${projectData.name} has been created successfully`,
        duration: 5000,
      },
    ])
  }

  const handleViewTasks = (projectId: string, projectName: string) => {
    setSelectedProjectForTasks({ id: projectId, name: projectName })
    setCurrentView("tasks")
  }

  const handleBackToDashboard = () => {
    setCurrentView("dashboard")
    setSelectedProjectForTasks(null)
  }

  const handleMarkAsRead = (id: string) => {
    setNotifications(notifications.map((n) => (n.id === id ? { ...n, read: true } : n)))
  }

  const handleMarkAllAsRead = () => {
    setNotifications(notifications.map((n) => ({ ...n, read: true })))
  }

  const handleDeleteNotification = (id: string) => {
    setNotifications(notifications.filter((n) => n.id !== id))
  }

  const handleDismissToast = (id: string) => {
    setToastNotifications(toastNotifications.filter((n) => n.id !== id))
  }

  const unreadCount = notifications.filter((n) => !n.read).length

  if (currentView === "tasks") {
    return (
      <TaskManagement
        projectId={selectedProjectForTasks?.id}
        projectName={selectedProjectForTasks?.name}
        onBack={handleBackToDashboard}
      />
    )
  }

  if (currentView === "team") {
    return <TeamManagement onBack={handleBackToDashboard} />
  }

  if (currentView === "communication") {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <Zap className="w-5 h-5 text-white" />
                </div>
                <h1 className="text-xl font-bold">SynergySphere</h1>
              </div>
              <div className="flex items-center gap-4">
                <Button variant="outline" onClick={handleBackToDashboard}>
                  Back to Dashboard
                </Button>
                <div className="flex items-center gap-2">
                  <Avatar className="w-8 h-8">
                    <AvatarFallback className="text-sm">{user?.name?.charAt(0).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="hidden sm:block">
                    <p className="text-sm font-medium">{user?.name}</p>
                    <p className="text-xs text-muted-foreground">{user?.role}</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm" onClick={logout}>
                  <LogOut className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </header>
        <div className="h-[calc(100vh-80px)]">
          <CommunicationHub />
        </div>
      </div>
    )
  }

  if (currentView === "analytics") {
    return <ProgressVisualization onBack={handleBackToDashboard} />
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold">SynergySphere</h1>
            </div>

            <div className="flex items-center gap-4">
              <Button variant="outline" onClick={() => setCurrentView("team")}>
                <UserCheck className="w-4 h-4 mr-2" />
                Team
              </Button>
              <Button variant="outline" onClick={() => setCurrentView("tasks")}>
                <ClipboardList className="w-4 h-4 mr-2" />
                Tasks
              </Button>
              <Button variant="outline" onClick={() => setCurrentView("communication")}>
                <MessageSquare className="w-4 h-4 mr-2" />
                Chat
              </Button>
              <Button variant="outline" onClick={() => setCurrentView("analytics")}>
                <BarChart3 className="w-4 h-4 mr-2" />
                Analytics
              </Button>
              <Button variant="outline" size="sm" onClick={() => setShowNotifications(true)} className="relative">
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <Badge
                    variant="destructive"
                    className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center text-xs"
                  >
                    {unreadCount}
                  </Badge>
                )}
              </Button>
              <div className="flex items-center gap-2">
                <Avatar className="w-8 h-8">
                  <AvatarFallback className="text-sm">{user?.name?.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="hidden sm:block">
                  <p className="text-sm font-medium">{user?.name}</p>
                  <p className="text-xs text-muted-foreground">{user?.role}</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={logout}>
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-2">Welcome back, {user?.name}!</h2>
          <p className="text-muted-foreground">Here's what's happening with your projects today.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Active Projects</p>
                  <p className="text-2xl font-bold">{stats.activeProjects}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
                  <BarChart3 className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Team Members</p>
                  <p className="text-2xl font-bold">{stats.totalMembers}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Tasks Completed</p>
                  <p className="text-2xl font-bold">{stats.completedTasks}</p>
                  <p className="text-xs text-muted-foreground">of {stats.totalTasks} total</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/20 rounded-lg flex items-center justify-center">
                  <CheckSquare className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Completion Rate</p>
                  <p className="text-2xl font-bold">{Math.round((stats.completedTasks / stats.totalTasks) * 100)}%</p>
                </div>
                <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900/20 rounded-lg flex items-center justify-center">
                  <MessageSquare className="w-6 h-6 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mb-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
            <h3 className="text-xl font-semibold">Project Dashboard</h3>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => setViewMode(viewMode === "grid" ? "list" : "grid")}>
                {viewMode === "grid" ? <List className="w-4 h-4" /> : <Grid className="w-4 h-4" />}
              </Button>
              <Button onClick={() => setShowCreateModal(true)}>
                <Plus className="w-4 h-4 mr-2" />
                New Project
              </Button>
            </div>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Search projects..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Planning">Planning</SelectItem>
                <SelectItem value="In Progress">In Progress</SelectItem>
                <SelectItem value="Review">Review</SelectItem>
                <SelectItem value="Completed">Completed</SelectItem>
                <SelectItem value="On Hold">On Hold</SelectItem>
              </SelectContent>
            </Select>
            <Select value={priorityFilter} onValueChange={setPriorityFilter}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Filter by priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priority</SelectItem>
                <SelectItem value="Critical">Critical</SelectItem>
                <SelectItem value="High">High</SelectItem>
                <SelectItem value="Medium">Medium</SelectItem>
                <SelectItem value="Low">Low</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {viewMode === "grid" ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredProjects.map((project) => (
              <Card key={project.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{project.name}</CardTitle>
                      <CardDescription className="mt-1">{project.description}</CardDescription>
                    </div>
                    <div className="flex flex-col gap-2 ml-2">
                      <Badge className={getStatusColor(project.status)}>{project.status}</Badge>
                      <Badge variant="outline" className={getPriorityColor(project.priority)}>
                        {project.priority}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Progress Bar */}
                    <div>
                      <div className="flex items-center justify-between text-sm mb-2">
                        <span className="text-muted-foreground">Progress</span>
                        <span className="font-medium">{project.progress}%</span>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div
                          className="bg-gradient-to-r from-blue-600 to-purple-600 h-2 rounded-full transition-all"
                          style={{ width: `${project.progress}%` }}
                        />
                      </div>
                    </div>

                    {/* Project Stats */}
                    <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        <span>{project.members} members</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <CheckSquare className="w-4 h-4" />
                        <span>
                          {project.completedTasks}/{project.tasks} tasks
                        </span>
                      </div>
                    </div>

                    {/* Due Date and Owner */}
                    <div className="space-y-2 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        <span>Due {project.dueDate}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Owner: {project.owner}</span>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="sm" onClick={() => handleViewTasks(project.id, project.name)}>
                            <ClipboardList className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => setSelectedProject(project)}>
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Settings className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {filteredProjects.map((project) => (
              <Card key={project.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-4 mb-2">
                        <h3 className="text-lg font-semibold">{project.name}</h3>
                        <Badge className={getStatusColor(project.status)}>{project.status}</Badge>
                        <Badge variant="outline" className={getPriorityColor(project.priority)}>
                          {project.priority}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground mb-4">{project.description}</p>
                      <div className="flex items-center gap-6 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          <span>{project.members} members</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <CheckSquare className="w-4 h-4" />
                          <span>
                            {project.completedTasks}/{project.tasks} tasks
                          </span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          <span>Due {project.dueDate}</span>
                        </div>
                        <span>Owner: {project.owner}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <div className="text-sm text-muted-foreground mb-1">Progress</div>
                        <div className="text-lg font-semibold">{project.progress}%</div>
                      </div>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="sm" onClick={() => handleViewTasks(project.id, project.name)}>
                          <ClipboardList className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => setSelectedProject(project)}>
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Settings className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {filteredProjects.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <BarChart3 className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No projects found</h3>
            <p className="text-muted-foreground mb-4">Try adjusting your search or filters, or create a new project.</p>
            <Button onClick={() => setShowCreateModal(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Create Your First Project
            </Button>
          </div>
        )}
      </div>

      <ProjectCreationModal
        open={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onCreateProject={handleCreateProject}
      />

      {selectedProject && (
        <ProjectDetailModal
          project={selectedProject}
          open={!!selectedProject}
          onClose={() => setSelectedProject(null)}
        />
      )}

      <NotificationCenter
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
        notifications={notifications}
        onMarkAsRead={handleMarkAsRead}
        onMarkAllAsRead={handleMarkAllAsRead}
        onDeleteNotification={handleDeleteNotification}
      />

      <ToastNotifications notifications={toastNotifications} onDismiss={handleDismissToast} />
    </div>
  )
}
