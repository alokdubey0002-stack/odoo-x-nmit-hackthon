"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Calendar, Users, CheckSquare, DollarSign, Clock, Target, MessageSquare, Settings, Edit } from "lucide-react"

interface Project {
  id: string
  name: string
  description: string
  status: "Planning" | "In Progress" | "Review" | "Completed" | "On Hold"
  priority: "Low" | "Medium" | "High" | "Critical"
  progress: number
  members: number
  tasks: number
  completedTasks: number
  dueDate: string
  createdDate: string
  category: "Development" | "Design" | "Marketing" | "Research" | "Operations"
  budget?: number
  owner: string
}

interface ProjectDetailModalProps {
  project: Project
  open: boolean
  onClose: () => void
}

export function ProjectDetailModal({ project, open, onClose }: ProjectDetailModalProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "In Progress":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400"
      case "Planning":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400"
      case "Review":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400"
      case "Completed":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400"
      case "On Hold":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "Critical":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400"
      case "High":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400"
      case "Medium":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400"
      case "Low":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
    }
  }

  const mockTeamMembers = [
    { id: "1", name: "Sarah Johnson", role: "Project Manager", avatar: "SJ" },
    { id: "2", name: "Mike Chen", role: "Developer", avatar: "MC" },
    { id: "3", name: "Lisa Park", role: "Designer", avatar: "LP" },
    { id: "4", name: "David Kim", role: "QA Engineer", avatar: "DK" },
  ]

  const mockTasks = [
    { id: "1", title: "Design wireframes", status: "Completed", assignee: "Lisa Park" },
    { id: "2", title: "Set up development environment", status: "Completed", assignee: "Mike Chen" },
    { id: "3", title: "Implement user authentication", status: "In Progress", assignee: "Mike Chen" },
    { id: "4", title: "Create responsive layouts", status: "In Progress", assignee: "Lisa Park" },
    { id: "5", title: "Write test cases", status: "Todo", assignee: "David Kim" },
  ]

  const mockActivity = [
    { id: "1", user: "Sarah Johnson", action: "updated project status", time: "2 hours ago" },
    { id: "2", user: "Mike Chen", action: "completed task 'Set up development environment'", time: "4 hours ago" },
    { id: "3", user: "Lisa Park", action: "uploaded new design mockups", time: "1 day ago" },
    { id: "4", user: "David Kim", action: "added 3 new test cases", time: "2 days ago" },
  ]

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[900px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div>
              <DialogTitle className="text-2xl">{project.name}</DialogTitle>
              <div className="flex items-center gap-2 mt-2">
                <Badge className={getStatusColor(project.status)}>{project.status}</Badge>
                <Badge variant="outline" className={getPriorityColor(project.priority)}>
                  {project.priority} Priority
                </Badge>
                <Badge variant="outline">{project.category}</Badge>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Edit className="w-4 h-4 mr-2" />
                Edit
              </Button>
              <Button variant="outline" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Project Overview */}
          <div>
            <p className="text-muted-foreground">{project.description}</p>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-blue-600" />
                  <div>
                    <p className="text-sm text-muted-foreground">Progress</p>
                    <p className="text-lg font-semibold">{project.progress}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-green-600" />
                  <div>
                    <p className="text-sm text-muted-foreground">Team Size</p>
                    <p className="text-lg font-semibold">{project.members}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <CheckSquare className="w-4 h-4 text-purple-600" />
                  <div>
                    <p className="text-sm text-muted-foreground">Tasks</p>
                    <p className="text-lg font-semibold">
                      {project.completedTasks}/{project.tasks}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-orange-600" />
                  <div>
                    <p className="text-sm text-muted-foreground">Due Date</p>
                    <p className="text-lg font-semibold">{project.dueDate}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Progress Bar */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-medium">Overall Progress</h4>
              <span className="text-sm text-muted-foreground">{project.progress}% Complete</span>
            </div>
            <Progress value={project.progress} className="h-2" />
          </div>

          {/* Detailed Tabs */}
          <Tabs defaultValue="tasks" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="tasks">Tasks</TabsTrigger>
              <TabsTrigger value="team">Team</TabsTrigger>
              <TabsTrigger value="activity">Activity</TabsTrigger>
              <TabsTrigger value="details">Details</TabsTrigger>
            </TabsList>

            <TabsContent value="tasks" className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium">Project Tasks</h4>
                <Button size="sm">Add Task</Button>
              </div>
              <div className="space-y-2">
                {mockTasks.map((task) => (
                  <div key={task.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <CheckSquare
                        className={`w-4 h-4 ${task.status === "Completed" ? "text-green-600" : "text-gray-400"}`}
                      />
                      <div>
                        <p className="font-medium">{task.title}</p>
                        <p className="text-sm text-muted-foreground">Assigned to {task.assignee}</p>
                      </div>
                    </div>
                    <Badge
                      variant={
                        task.status === "Completed"
                          ? "default"
                          : task.status === "In Progress"
                            ? "secondary"
                            : "outline"
                      }
                    >
                      {task.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="team" className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium">Team Members</h4>
                <Button size="sm">Add Member</Button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {mockTeamMembers.map((member) => (
                  <div key={member.id} className="flex items-center gap-3 p-3 border rounded-lg">
                    <Avatar>
                      <AvatarFallback>{member.avatar}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{member.name}</p>
                      <p className="text-sm text-muted-foreground">{member.role}</p>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="activity" className="space-y-4">
              <h4 className="font-medium">Recent Activity</h4>
              <div className="space-y-3">
                {mockActivity.map((activity) => (
                  <div key={activity.id} className="flex items-start gap-3 p-3 border rounded-lg">
                    <MessageSquare className="w-4 h-4 mt-1 text-blue-600" />
                    <div>
                      <p className="text-sm">
                        <span className="font-medium">{activity.user}</span> {activity.action}
                      </p>
                      <p className="text-xs text-muted-foreground">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="details" className="space-y-4">
              <h4 className="font-medium">Project Details</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Project Owner</label>
                    <p className="mt-1">{project.owner}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Created Date</label>
                    <p className="mt-1">{project.createdDate}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Category</label>
                    <p className="mt-1">{project.category}</p>
                  </div>
                </div>
                <div className="space-y-4">
                  {project.budget && (
                    <div>
                      <label className="text-sm font-medium text-muted-foreground">Budget</label>
                      <p className="mt-1 flex items-center gap-1">
                        <DollarSign className="w-4 h-4" />
                        {project.budget.toLocaleString()}
                      </p>
                    </div>
                  )}
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Due Date</label>
                    <p className="mt-1 flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {project.dueDate}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Time Remaining</label>
                    <p className="mt-1 flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {Math.ceil((new Date(project.dueDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))}{" "}
                      days
                    </p>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  )
}
