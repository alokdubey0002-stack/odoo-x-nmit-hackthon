"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import {
  Mail,
  Phone,
  MapPin,
  Calendar,
  Clock,
  Shield,
  Edit,
  MessageSquare,
  CheckSquare,
  BarChart3,
  Users,
  Activity,
  Settings,
} from "lucide-react"

interface TeamMember {
  id: string
  name: string
  email: string
  avatar: string
  role: "Owner" | "Admin" | "Manager" | "Member" | "Viewer"
  department: string
  title: string
  location: string
  phone?: string
  joinDate: string
  lastActive: string
  status: "Active" | "Away" | "Busy" | "Offline"
  projects: number
  tasksCompleted: number
  tasksActive: number
  skills: string[]
  bio?: string
}

interface TeamMemberModalProps {
  member: TeamMember
  open: boolean
  onClose: () => void
}

export function TeamMemberModal({ member, open, onClose }: TeamMemberModalProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400"
      case "Away":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400"
      case "Busy":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400"
      case "Offline":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
    }
  }

  const getRoleColor = (role: string) => {
    switch (role) {
      case "Owner":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400"
      case "Admin":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400"
      case "Manager":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400"
      case "Member":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400"
      case "Viewer":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
    }
  }

  const mockProjects = [
    { id: "1", name: "Website Redesign", role: "Lead Designer", progress: 75 },
    { id: "2", name: "Mobile App", role: "UI Designer", progress: 45 },
    { id: "3", name: "Brand Guidelines", role: "Designer", progress: 90 },
  ]

  const mockRecentActivity = [
    { id: "1", action: "Completed task 'Design user profile page'", time: "2 hours ago" },
    { id: "2", action: "Commented on 'Mobile navigation component'", time: "4 hours ago" },
    { id: "3", action: "Updated project status for Website Redesign", time: "1 day ago" },
    { id: "4", action: "Joined project 'Brand Guidelines'", time: "3 days ago" },
  ]

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              <div className="relative">
                <Avatar className="w-16 h-16">
                  <AvatarFallback className="text-2xl font-semibold">{member.avatar}</AvatarFallback>
                </Avatar>
                <div
                  className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full border-2 border-white ${
                    member.status === "Active"
                      ? "bg-green-500"
                      : member.status === "Away"
                        ? "bg-yellow-500"
                        : member.status === "Busy"
                          ? "bg-red-500"
                          : "bg-gray-400"
                  }`}
                />
              </div>
              <div>
                <DialogTitle className="text-2xl">{member.name}</DialogTitle>
                <p className="text-lg text-muted-foreground">{member.title}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge className={getRoleColor(member.role)}>
                    <Shield className="w-3 h-3 mr-1" />
                    {member.role}
                  </Badge>
                  <Badge className={getStatusColor(member.status)}>{member.status}</Badge>
                  <Badge variant="outline">{member.department}</Badge>
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <MessageSquare className="w-4 h-4 mr-2" />
                Message
              </Button>
              <Button variant="outline" size="sm">
                <Edit className="w-4 h-4 mr-2" />
                Edit
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Bio */}
          {member.bio && (
            <div>
              <p className="text-muted-foreground">{member.bio}</p>
            </div>
          )}

          {/* Contact Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardContent className="p-4">
                <h4 className="font-medium mb-3">Contact Information</h4>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">{member.email}</span>
                  </div>
                  {member.phone && (
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">{member.phone}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">{member.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">Joined {member.joinDate}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">Last active: {member.lastActive}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <h4 className="font-medium mb-3">Work Statistics</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-blue-600" />
                      <span className="text-sm">Active Projects</span>
                    </div>
                    <span className="font-semibold">{member.projects}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CheckSquare className="w-4 h-4 text-green-600" />
                      <span className="text-sm">Tasks Completed</span>
                    </div>
                    <span className="font-semibold">{member.tasksCompleted}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-purple-600" />
                      <span className="text-sm">Active Tasks</span>
                    </div>
                    <span className="font-semibold">{member.tasksActive}</span>
                  </div>
                  <div className="pt-2">
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span className="text-muted-foreground">Completion Rate</span>
                      <span className="font-medium">
                        {Math.round((member.tasksCompleted / (member.tasksCompleted + member.tasksActive)) * 100)}%
                      </span>
                    </div>
                    <Progress
                      value={(member.tasksCompleted / (member.tasksCompleted + member.tasksActive)) * 100}
                      className="h-2"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Skills */}
          <div>
            <h4 className="font-medium mb-3">Skills & Expertise</h4>
            <div className="flex flex-wrap gap-2">
              {member.skills.map((skill) => (
                <Badge key={skill} variant="secondary">
                  {skill}
                </Badge>
              ))}
            </div>
          </div>

          {/* Detailed Tabs */}
          <Tabs defaultValue="projects" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="projects">Projects</TabsTrigger>
              <TabsTrigger value="activity">Activity</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="projects" className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium">Current Projects</h4>
                <Badge variant="outline">{mockProjects.length} active</Badge>
              </div>
              <div className="space-y-3">
                {mockProjects.map((project) => (
                  <Card key={project.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <h5 className="font-medium">{project.name}</h5>
                          <p className="text-sm text-muted-foreground">{project.role}</p>
                        </div>
                        <Badge variant="outline">{project.progress}%</Badge>
                      </div>
                      <Progress value={project.progress} className="h-2" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="activity" className="space-y-4">
              <h4 className="font-medium">Recent Activity</h4>
              <div className="space-y-3">
                {mockRecentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-start gap-3 p-3 border rounded-lg">
                    <Activity className="w-4 h-4 mt-1 text-blue-600" />
                    <div>
                      <p className="text-sm">{activity.action}</p>
                      <p className="text-xs text-muted-foreground">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="settings" className="space-y-4">
              <h4 className="font-medium">Member Settings</h4>
              <div className="space-y-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h5 className="font-medium">Role & Permissions</h5>
                        <p className="text-sm text-muted-foreground">Current role: {member.role}</p>
                      </div>
                      <Button variant="outline" size="sm">
                        <Settings className="w-4 h-4 mr-2" />
                        Manage
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h5 className="font-medium">Department Transfer</h5>
                        <p className="text-sm text-muted-foreground">Current department: {member.department}</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Transfer
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h5 className="font-medium">Account Status</h5>
                        <p className="text-sm text-muted-foreground">Member since {member.joinDate}</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Deactivate
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  )
}
