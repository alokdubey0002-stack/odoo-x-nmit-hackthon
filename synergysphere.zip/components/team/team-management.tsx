"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Mail, MapPin, Settings, MoreHorizontal, ArrowLeft, Users, UserPlus, Clock } from "lucide-react"
import { TeamInviteModal } from "./team-invite-modal"
import { TeamMemberModal } from "./team-member-modal"
import { TeamSettingsModal } from "./team-settings-modal"

interface TeamMember {
  id: string
  name: string
  email: string
  avatar: string
  role: "Owner" | "Admin" | "Manager" | "Member" | "Viewer"
  department: string
  title: string
  location: string
  phone?: string
  joinDate: string
  lastActive: string
  status: "Active" | "Away" | "Busy" | "Offline"
  projects: number
  tasksCompleted: number
  tasksActive: number
  skills: string[]
  bio?: string
}

interface TeamManagementProps {
  onBack?: () => void
}

export function TeamManagement({ onBack }: TeamManagementProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [roleFilter, setRoleFilter] = useState<string>("all")
  const [departmentFilter, setDepartmentFilter] = useState<string>("all")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [showInviteModal, setShowInviteModal] = useState(false)
  const [showSettingsModal, setShowSettingsModal] = useState(false)
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null)

  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([
    {
      id: "1",
      name: "Sarah Johnson",
      email: "sarah.johnson@company.com",
      avatar: "SJ",
      role: "Owner",
      department: "Leadership",
      title: "Product Manager",
      location: "San Francisco, CA",
      phone: "+1 (555) 123-4567",
      joinDate: "2023-01-15",
      lastActive: "2 minutes ago",
      status: "Active",
      projects: 5,
      tasksCompleted: 47,
      tasksActive: 8,
      skills: ["Product Strategy", "Team Leadership", "Agile", "User Research"],
      bio: "Experienced product manager with 8+ years in tech. Passionate about building user-centered products.",
    },
    {
      id: "2",
      name: "Mike Chen",
      email: "mike.chen@company.com",
      avatar: "MC",
      role: "Admin",
      department: "Engineering",
      title: "Senior Full Stack Developer",
      location: "Seattle, WA",
      phone: "+1 (555) 234-5678",
      joinDate: "2023-02-01",
      lastActive: "15 minutes ago",
      status: "Active",
      projects: 3,
      tasksCompleted: 89,
      tasksActive: 12,
      skills: ["React", "Node.js", "TypeScript", "AWS", "Database Design"],
      bio: "Full-stack developer specializing in modern web technologies and cloud architecture.",
    },
    {
      id: "3",
      name: "Lisa Park",
      email: "lisa.park@company.com",
      avatar: "LP",
      role: "Manager",
      department: "Design",
      title: "Senior UX Designer",
      location: "Austin, TX",
      joinDate: "2023-03-10",
      lastActive: "1 hour ago",
      status: "Away",
      projects: 4,
      tasksCompleted: 34,
      tasksActive: 6,
      skills: ["UI/UX Design", "Figma", "User Research", "Prototyping", "Design Systems"],
      bio: "Creative designer focused on creating intuitive and beautiful user experiences.",
    },
    {
      id: "4",
      name: "David Kim",
      email: "david.kim@company.com",
      avatar: "DK",
      role: "Member",
      department: "Engineering",
      title: "QA Engineer",
      location: "New York, NY",
      joinDate: "2023-04-05",
      lastActive: "3 hours ago",
      status: "Busy",
      projects: 2,
      tasksCompleted: 56,
      tasksActive: 4,
      skills: ["Test Automation", "Quality Assurance", "Selenium", "API Testing"],
      bio: "Detail-oriented QA engineer ensuring product quality and reliability.",
    },
    {
      id: "5",
      name: "Emily Rodriguez",
      email: "emily.rodriguez@company.com",
      avatar: "ER",
      role: "Member",
      department: "Marketing",
      title: "Marketing Specialist",
      location: "Miami, FL",
      joinDate: "2023-05-20",
      lastActive: "1 day ago",
      status: "Offline",
      projects: 3,
      tasksCompleted: 28,
      tasksActive: 5,
      skills: ["Digital Marketing", "Content Strategy", "SEO", "Analytics"],
      bio: "Marketing professional with expertise in digital campaigns and content creation.",
    },
    {
      id: "6",
      name: "Alex Thompson",
      email: "alex.thompson@company.com",
      avatar: "AT",
      role: "Viewer",
      department: "Sales",
      title: "Sales Representative",
      location: "Chicago, IL",
      joinDate: "2023-06-15",
      lastActive: "2 days ago",
      status: "Offline",
      projects: 1,
      tasksCompleted: 12,
      tasksActive: 2,
      skills: ["Sales", "Customer Relations", "CRM", "Negotiation"],
      bio: "Sales professional focused on building strong customer relationships.",
    },
  ])

  const filteredMembers = teamMembers.filter((member) => {
    const matchesSearch =
      member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.skills.some((skill) => skill.toLowerCase().includes(searchQuery.toLowerCase()))

    const matchesRole = roleFilter === "all" || member.role === roleFilter
    const matchesDepartment = departmentFilter === "all" || member.department === departmentFilter
    const matchesStatus = statusFilter === "all" || member.status === statusFilter

    return matchesSearch && matchesRole && matchesDepartment && matchesStatus
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400"
      case "Away":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400"
      case "Busy":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400"
      case "Offline":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
    }
  }

  const getRoleColor = (role: string) => {
    switch (role) {
      case "Owner":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400"
      case "Admin":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400"
      case "Manager":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400"
      case "Member":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400"
      case "Viewer":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
    }
  }

  const uniqueDepartments = Array.from(new Set(teamMembers.map((member) => member.department)))

  const teamStats = {
    total: teamMembers.length,
    active: teamMembers.filter((m) => m.status === "Active").length,
    projects: teamMembers.reduce((sum, m) => sum + m.projects, 0),
    completedTasks: teamMembers.reduce((sum, m) => sum + m.tasksCompleted, 0),
  }

  const handleInviteMember = (memberData: any) => {
    const newMember: TeamMember = {
      ...memberData,
      id: Date.now().toString(),
      avatar: memberData.name
        .split(" ")
        .map((n: string) => n[0])
        .join(""),
      joinDate: new Date().toISOString().split("T")[0],
      lastActive: "Just joined",
      status: "Active" as const,
      projects: 0,
      tasksCompleted: 0,
      tasksActive: 0,
    }
    setTeamMembers([...teamMembers, newMember])
    setShowInviteModal(false)
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {onBack && (
                <Button variant="ghost" size="sm" onClick={onBack}>
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              )}
              <div>
                <h1 className="text-2xl font-bold">Team Management</h1>
                <p className="text-muted-foreground">Manage your team members, roles, and collaboration</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" onClick={() => setShowSettingsModal(true)}>
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </Button>
              <Button onClick={() => setShowInviteModal(true)}>
                <UserPlus className="w-4 h-4 mr-2" />
                Invite Member
              </Button>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            <Card>
              <CardContent className="p-4">
                <div className="text-center">
                  <p className="text-2xl font-bold">{teamStats.total}</p>
                  <p className="text-sm text-muted-foreground">Team Members</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-green-600">{teamStats.active}</p>
                  <p className="text-sm text-muted-foreground">Active Now</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-blue-600">{teamStats.projects}</p>
                  <p className="text-sm text-muted-foreground">Active Projects</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-purple-600">{teamStats.completedTasks}</p>
                  <p className="text-sm text-muted-foreground">Tasks Completed</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        {/* Filters and Search */}
        <div className="flex flex-col lg:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search team members, roles, or skills..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                <SelectItem value="Owner">Owner</SelectItem>
                <SelectItem value="Admin">Admin</SelectItem>
                <SelectItem value="Manager">Manager</SelectItem>
                <SelectItem value="Member">Member</SelectItem>
                <SelectItem value="Viewer">Viewer</SelectItem>
              </SelectContent>
            </Select>

            <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Department" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Departments</SelectItem>
                {uniqueDepartments.map((dept) => (
                  <SelectItem key={dept} value={dept}>
                    {dept}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Away">Away</SelectItem>
                <SelectItem value="Busy">Busy</SelectItem>
                <SelectItem value="Offline">Offline</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Team Members Grid */}
        <Tabs defaultValue="grid" className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="grid">Grid View</TabsTrigger>
            <TabsTrigger value="list">List View</TabsTrigger>
            <TabsTrigger value="org">Org Chart</TabsTrigger>
          </TabsList>

          <TabsContent value="grid">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredMembers.map((member) => (
                <Card key={member.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader className="pb-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <Avatar className="w-12 h-12">
                            <AvatarFallback className="text-lg font-semibold">{member.avatar}</AvatarFallback>
                          </Avatar>
                          <div
                            className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${
                              member.status === "Active"
                                ? "bg-green-500"
                                : member.status === "Away"
                                  ? "bg-yellow-500"
                                  : member.status === "Busy"
                                    ? "bg-red-500"
                                    : "bg-gray-400"
                            }`}
                          />
                        </div>
                        <div>
                          <h3 className="font-semibold">{member.name}</h3>
                          <p className="text-sm text-muted-foreground">{member.title}</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardHeader>

                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Badge className={getRoleColor(member.role)}>{member.role}</Badge>
                        <Badge className={getStatusColor(member.status)}>{member.status}</Badge>
                      </div>

                      <div className="space-y-2 text-sm text-muted-foreground">
                        <div className="flex items-center gap-2">
                          <Mail className="w-4 h-4" />
                          <span className="truncate">{member.email}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4" />
                          <span>{member.location}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4" />
                          <span>Last active: {member.lastActive}</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-2 text-center text-sm">
                        <div>
                          <p className="font-semibold">{member.projects}</p>
                          <p className="text-muted-foreground">Projects</p>
                        </div>
                        <div>
                          <p className="font-semibold">{member.tasksCompleted}</p>
                          <p className="text-muted-foreground">Completed</p>
                        </div>
                        <div>
                          <p className="font-semibold">{member.tasksActive}</p>
                          <p className="text-muted-foreground">Active</p>
                        </div>
                      </div>

                      <div className="flex flex-wrap gap-1">
                        {member.skills.slice(0, 3).map((skill) => (
                          <Badge key={skill} variant="secondary" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                        {member.skills.length > 3 && (
                          <Badge variant="secondary" className="text-xs">
                            +{member.skills.length - 3}
                          </Badge>
                        )}
                      </div>

                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full bg-transparent"
                        onClick={() => setSelectedMember(member)}
                      >
                        View Profile
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="list">
            <div className="space-y-4">
              {filteredMembers.map((member) => (
                <Card key={member.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="relative">
                          <Avatar className="w-12 h-12">
                            <AvatarFallback className="text-lg font-semibold">{member.avatar}</AvatarFallback>
                          </Avatar>
                          <div
                            className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${
                              member.status === "Active"
                                ? "bg-green-500"
                                : member.status === "Away"
                                  ? "bg-yellow-500"
                                  : member.status === "Busy"
                                    ? "bg-red-500"
                                    : "bg-gray-400"
                            }`}
                          />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-1">
                            <h3 className="font-semibold">{member.name}</h3>
                            <Badge className={getRoleColor(member.role)}>{member.role}</Badge>
                            <Badge className={getStatusColor(member.status)}>{member.status}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            {member.title} • {member.department}
                          </p>
                          <div className="flex items-center gap-6 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Mail className="w-4 h-4" />
                              <span>{member.email}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <MapPin className="w-4 h-4" />
                              <span>{member.location}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              <span>Last active: {member.lastActive}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-6">
                        <div className="text-center">
                          <p className="text-lg font-semibold">{member.projects}</p>
                          <p className="text-xs text-muted-foreground">Projects</p>
                        </div>
                        <div className="text-center">
                          <p className="text-lg font-semibold">{member.tasksCompleted}</p>
                          <p className="text-xs text-muted-foreground">Completed</p>
                        </div>
                        <div className="text-center">
                          <p className="text-lg font-semibold">{member.tasksActive}</p>
                          <p className="text-xs text-muted-foreground">Active</p>
                        </div>
                        <Button variant="outline" size="sm" onClick={() => setSelectedMember(member)}>
                          View Profile
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="org">
            <div className="text-center py-12">
              <Users className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Organization Chart</h3>
              <p className="text-muted-foreground">Visual organization chart coming soon</p>
            </div>
          </TabsContent>
        </Tabs>

        {filteredMembers.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No team members found</h3>
            <p className="text-muted-foreground mb-4">Try adjusting your search or filters.</p>
            <Button onClick={() => setShowInviteModal(true)}>
              <UserPlus className="w-4 h-4 mr-2" />
              Invite Team Member
            </Button>
          </div>
        )}
      </div>

      <TeamInviteModal
        open={showInviteModal}
        onClose={() => setShowInviteModal(false)}
        onInviteMember={handleInviteMember}
      />

      <TeamSettingsModal open={showSettingsModal} onClose={() => setShowSettingsModal(false)} />

      {selectedMember && (
        <TeamMemberModal member={selectedMember} open={!!selectedMember} onClose={() => setSelectedMember(null)} />
      )}
    </div>
  )
}
