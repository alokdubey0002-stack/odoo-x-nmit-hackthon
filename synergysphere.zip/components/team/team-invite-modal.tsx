"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Mail, Plus, X } from "lucide-react"

interface TeamInviteModalProps {
  open: boolean
  onClose: () => void
  onInviteMember: (memberData: any) => void
}

export function TeamInviteModal({ open, onClose, onInviteMember }: TeamInviteModalProps) {
  const [inviteMethod, setInviteMethod] = useState<"single" | "bulk">("single")
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    role: "Member" as const,
    department: "",
    title: "",
    location: "",
    phone: "",
    message: "",
  })
  const [bulkEmails, setBulkEmails] = useState<string[]>([])
  const [bulkEmailInput, setBulkEmailInput] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const departments = ["Engineering", "Design", "Marketing", "Sales", "Leadership", "Operations", "HR"]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (inviteMethod === "single" && (!formData.name || !formData.email)) return
    if (inviteMethod === "bulk" && bulkEmails.length === 0) return

    setIsSubmitting(true)

    if (inviteMethod === "single") {
      const memberData = {
        ...formData,
        skills: [],
        bio: "",
      }

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      onInviteMember(memberData)
    } else {
      // Handle bulk invite
      for (const email of bulkEmails) {
        const memberData = {
          name: email
            .split("@")[0]
            .replace(/[._]/g, " ")
            .replace(/\b\w/g, (l) => l.toUpperCase()),
          email,
          role: formData.role,
          department: formData.department || "Engineering",
          title: "Team Member",
          location: "Remote",
          phone: "",
          skills: [],
          bio: "",
        }
        onInviteMember(memberData)
      }
    }

    // Reset form
    setFormData({
      name: "",
      email: "",
      role: "Member",
      department: "",
      title: "",
      location: "",
      phone: "",
      message: "",
    })
    setBulkEmails([])
    setBulkEmailInput("")
    setIsSubmitting(false)
  }

  const handleAddBulkEmail = () => {
    const emails = bulkEmailInput
      .split(/[,\n]/)
      .map((email) => email.trim())
      .filter((email) => email && email.includes("@"))
      .filter((email) => !bulkEmails.includes(email))

    setBulkEmails([...bulkEmails, ...emails])
    setBulkEmailInput("")
  }

  const handleRemoveBulkEmail = (emailToRemove: string) => {
    setBulkEmails(bulkEmails.filter((email) => email !== emailToRemove))
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Invite Team Members</DialogTitle>
          <DialogDescription>Add new team members to your workspace and assign them roles.</DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Invite Method Toggle */}
          <div className="flex gap-2">
            <Button
              type="button"
              variant={inviteMethod === "single" ? "default" : "outline"}
              onClick={() => setInviteMethod("single")}
              className="flex-1"
            >
              Single Invite
            </Button>
            <Button
              type="button"
              variant={inviteMethod === "bulk" ? "default" : "outline"}
              onClick={() => setInviteMethod("bulk")}
              className="flex-1"
            >
              Bulk Invite
            </Button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {inviteMethod === "single" ? (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Enter full name"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="Enter email address"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Role</Label>
                    <Select
                      value={formData.role}
                      onValueChange={(value: any) => setFormData({ ...formData, role: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Viewer">Viewer</SelectItem>
                        <SelectItem value="Member">Member</SelectItem>
                        <SelectItem value="Manager">Manager</SelectItem>
                        <SelectItem value="Admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Department</Label>
                    <Select
                      value={formData.department}
                      onValueChange={(value) => setFormData({ ...formData, department: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent>
                        {departments.map((dept) => (
                          <SelectItem key={dept} value={dept}>
                            {dept}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Job Title</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      placeholder="Enter job title"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location">Location</Label>
                    <Input
                      id="location"
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                      placeholder="Enter location"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="Enter phone number"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message">Welcome Message (Optional)</Label>
                  <Textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Add a personal welcome message..."
                    rows={3}
                  />
                </div>
              </>
            ) : (
              <>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Email Addresses</Label>
                    <div className="flex gap-2">
                      <Textarea
                        value={bulkEmailInput}
                        onChange={(e) => setBulkEmailInput(e.target.value)}
                        placeholder="Enter email addresses separated by commas or new lines..."
                        rows={4}
                        className="flex-1"
                      />
                      <Button type="button" onClick={handleAddBulkEmail} disabled={!bulkEmailInput.trim()}>
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  {bulkEmails.length > 0 && (
                    <div className="space-y-2">
                      <Label>Email List ({bulkEmails.length})</Label>
                      <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto p-2 border rounded-md">
                        {bulkEmails.map((email) => (
                          <Badge key={email} variant="secondary" className="flex items-center gap-1">
                            <Mail className="w-3 h-3" />
                            {email}
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              className="h-auto p-0 w-4 h-4 ml-1"
                              onClick={() => handleRemoveBulkEmail(email)}
                            >
                              <X className="w-3 h-3" />
                            </Button>
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Default Role</Label>
                      <Select
                        value={formData.role}
                        onValueChange={(value: any) => setFormData({ ...formData, role: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Viewer">Viewer</SelectItem>
                          <SelectItem value="Member">Member</SelectItem>
                          <SelectItem value="Manager">Manager</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Default Department</Label>
                      <Select
                        value={formData.department}
                        onValueChange={(value) => setFormData({ ...formData, department: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select department" />
                        </SelectTrigger>
                        <SelectContent>
                          {departments.map((dept) => (
                            <SelectItem key={dept} value={dept}>
                              {dept}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </>
            )}

            <div className="flex justify-end gap-3 pt-4">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting
                  ? "Sending..."
                  : inviteMethod === "single"
                    ? "Send Invitation"
                    : `Send ${bulkEmails.length} Invitations`}
              </Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  )
}
