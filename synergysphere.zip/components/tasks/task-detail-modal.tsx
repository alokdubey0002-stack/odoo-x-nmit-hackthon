"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Card, CardContent } from "@/components/ui/card"
import {
  Calendar,
  Clock,
  Flag,
  User,
  MessageSquare,
  Paperclip,
  Edit,
  Save,
  X,
  Send,
  Plus,
  Download,
} from "lucide-react"

interface Task {
  id: string
  title: string
  description: string
  status: "Todo" | "In Progress" | "Review" | "Done"
  priority: "Low" | "Medium" | "High" | "Critical"
  assignee: string
  assigneeAvatar: string
  reporter: string
  projectId: string
  projectName: string
  dueDate: string
  createdDate: string
  updatedDate: string
  tags: string[]
  comments: number
  attachments: number
  estimatedHours?: number
  loggedHours?: number
}

interface TaskDetailModalProps {
  task: Task
  open: boolean
  onClose: () => void
  onUpdateTask: (taskId: string, updates: Partial<Task>) => void
}

export function TaskDetailModal({ task, open, onClose, onUpdateTask }: TaskDetailModalProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [editData, setEditData] = useState({
    title: task.title,
    description: task.description,
    status: task.status,
    priority: task.priority,
    assignee: task.assignee,
  })
  const [newComment, setNewComment] = useState("")
  const [timeLog, setTimeLog] = useState("")

  const mockComments = [
    {
      id: "1",
      author: "Sarah Johnson",
      avatar: "SJ",
      content: "I've reviewed the initial wireframes. Looking good overall, but we need to adjust the mobile layout.",
      timestamp: "2 hours ago",
    },
    {
      id: "2",
      author: "Mike Chen",
      avatar: "MC",
      content: "Started working on the backend API. Should have the first endpoints ready by tomorrow.",
      timestamp: "1 day ago",
    },
    {
      id: "3",
      author: "Lisa Park",
      avatar: "LP",
      content: "Updated the design based on feedback. New mockups are attached.",
      timestamp: "2 days ago",
    },
  ]

  const mockAttachments = [
    { id: "1", name: "wireframes-v2.pdf", size: "2.4 MB", type: "pdf" },
    { id: "2", name: "design-mockups.fig", size: "5.1 MB", type: "figma" },
    { id: "3", name: "requirements.docx", size: "1.2 MB", type: "document" },
  ]

  const mockTimeEntries = [
    { id: "1", user: "Lisa Park", hours: 3, description: "Created initial wireframes", date: "2024-01-20" },
    { id: "2", user: "Lisa Park", hours: 2, description: "Revised based on feedback", date: "2024-01-22" },
  ]

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "Critical":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400"
      case "High":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400"
      case "Medium":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400"
      case "Low":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Todo":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
      case "In Progress":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400"
      case "Review":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400"
      case "Done":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
    }
  }

  const handleSave = () => {
    onUpdateTask(task.id, editData)
    setIsEditing(false)
  }

  const handleCancel = () => {
    setEditData({
      title: task.title,
      description: task.description,
      status: task.status,
      priority: task.priority,
      assignee: task.assignee,
    })
    setIsEditing(false)
  }

  const handleAddComment = () => {
    if (newComment.trim()) {
      // In a real app, this would make an API call
      console.log("Adding comment:", newComment)
      setNewComment("")
    }
  }

  const handleLogTime = () => {
    if (timeLog.trim()) {
      const hours = Number.parseFloat(timeLog)
      if (hours > 0) {
        onUpdateTask(task.id, {
          loggedHours: (task.loggedHours || 0) + hours,
        })
        setTimeLog("")
      }
    }
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[900px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div className="flex-1">
              {isEditing ? (
                <Input
                  value={editData.title}
                  onChange={(e) => setEditData({ ...editData, title: e.target.value })}
                  className="text-xl font-semibold mb-2"
                />
              ) : (
                <DialogTitle className="text-xl">{task.title}</DialogTitle>
              )}
              <div className="flex items-center gap-2 mt-2">
                {isEditing ? (
                  <>
                    <Select
                      value={editData.status}
                      onValueChange={(value: any) => setEditData({ ...editData, status: value })}
                    >
                      <SelectTrigger className="w-[140px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Todo">Todo</SelectItem>
                        <SelectItem value="In Progress">In Progress</SelectItem>
                        <SelectItem value="Review">Review</SelectItem>
                        <SelectItem value="Done">Done</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select
                      value={editData.priority}
                      onValueChange={(value: any) => setEditData({ ...editData, priority: value })}
                    >
                      <SelectTrigger className="w-[140px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Low">Low</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="High">High</SelectItem>
                        <SelectItem value="Critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </>
                ) : (
                  <>
                    <Badge className={getStatusColor(task.status)}>{task.status}</Badge>
                    <Badge variant="outline" className={getPriorityColor(task.priority)}>
                      <Flag className="w-3 h-3 mr-1" />
                      {task.priority}
                    </Badge>
                    <Badge variant="outline">{task.projectName}</Badge>
                  </>
                )}
              </div>
            </div>
            <div className="flex gap-2">
              {isEditing ? (
                <>
                  <Button variant="outline" size="sm" onClick={handleCancel}>
                    <X className="w-4 h-4 mr-2" />
                    Cancel
                  </Button>
                  <Button size="sm" onClick={handleSave}>
                    <Save className="w-4 h-4 mr-2" />
                    Save
                  </Button>
                </>
              ) : (
                <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
                  <Edit className="w-4 h-4 mr-2" />
                  Edit
                </Button>
              )}
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Description */}
          <div>
            <h4 className="font-medium mb-2">Description</h4>
            {isEditing ? (
              <Textarea
                value={editData.description}
                onChange={(e) => setEditData({ ...editData, description: e.target.value })}
                rows={3}
              />
            ) : (
              <p className="text-muted-foreground">{task.description}</p>
            )}
          </div>

          {/* Task Details */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-blue-600" />
                  <div>
                    <p className="text-sm text-muted-foreground">Assignee</p>
                    <div className="flex items-center gap-2">
                      <Avatar className="w-5 h-5">
                        <AvatarFallback className="text-xs">{task.assigneeAvatar}</AvatarFallback>
                      </Avatar>
                      <p className="text-sm font-medium">{task.assignee}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-orange-600" />
                  <div>
                    <p className="text-sm text-muted-foreground">Due Date</p>
                    <p className="text-sm font-medium">{task.dueDate}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-green-600" />
                  <div>
                    <p className="text-sm text-muted-foreground">Time Logged</p>
                    <p className="text-sm font-medium">
                      {task.loggedHours || 0}h{task.estimatedHours && ` / ${task.estimatedHours}h`}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-purple-600" />
                  <div>
                    <p className="text-sm text-muted-foreground">Comments</p>
                    <p className="text-sm font-medium">{task.comments}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Progress Bar */}
          {task.estimatedHours && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium">Time Progress</h4>
                <span className="text-sm text-muted-foreground">
                  {Math.round(((task.loggedHours || 0) / task.estimatedHours) * 100)}% Complete
                </span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-blue-600 to-purple-600 h-2 rounded-full transition-all"
                  style={{
                    width: `${Math.min(((task.loggedHours || 0) / task.estimatedHours) * 100, 100)}%`,
                  }}
                />
              </div>
            </div>
          )}

          {/* Tags */}
          {task.tags.length > 0 && (
            <div>
              <h4 className="font-medium mb-2">Tags</h4>
              <div className="flex flex-wrap gap-2">
                {task.tags.map((tag) => (
                  <Badge key={tag} variant="secondary">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Detailed Tabs */}
          <Tabs defaultValue="comments" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="comments">Comments</TabsTrigger>
              <TabsTrigger value="attachments">Attachments</TabsTrigger>
              <TabsTrigger value="time">Time Tracking</TabsTrigger>
              <TabsTrigger value="activity">Activity</TabsTrigger>
            </TabsList>

            <TabsContent value="comments" className="space-y-4">
              <div className="space-y-4">
                {mockComments.map((comment) => (
                  <div key={comment.id} className="flex gap-3 p-4 border rounded-lg">
                    <Avatar className="w-8 h-8">
                      <AvatarFallback>{comment.avatar}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm">{comment.author}</span>
                        <span className="text-xs text-muted-foreground">{comment.timestamp}</span>
                      </div>
                      <p className="text-sm">{comment.content}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex gap-2">
                <Textarea
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Add a comment..."
                  rows={2}
                  className="flex-1"
                />
                <Button onClick={handleAddComment} disabled={!newComment.trim()}>
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="attachments" className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium">Attachments ({mockAttachments.length})</h4>
                <Button size="sm">
                  <Plus className="w-4 h-4 mr-2" />
                  Add File
                </Button>
              </div>
              <div className="space-y-2">
                {mockAttachments.map((attachment) => (
                  <div key={attachment.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <Paperclip className="w-4 h-4 text-muted-foreground" />
                      <div>
                        <p className="font-medium text-sm">{attachment.name}</p>
                        <p className="text-xs text-muted-foreground">{attachment.size}</p>
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="time" className="space-y-4">
              <div className="flex gap-2">
                <Input
                  type="number"
                  step="0.5"
                  min="0"
                  value={timeLog}
                  onChange={(e) => setTimeLog(e.target.value)}
                  placeholder="Hours worked"
                  className="w-32"
                />
                <Button onClick={handleLogTime} disabled={!timeLog.trim()}>
                  Log Time
                </Button>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium">Time Entries</h4>
                {mockTimeEntries.map((entry) => (
                  <div key={entry.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium text-sm">{entry.description}</p>
                      <p className="text-xs text-muted-foreground">
                        {entry.user} • {entry.date}
                      </p>
                    </div>
                    <Badge variant="outline">{entry.hours}h</Badge>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="activity" className="space-y-4">
              <div className="space-y-3">
                <div className="flex gap-3 p-3 border rounded-lg">
                  <Clock className="w-4 h-4 mt-1 text-blue-600" />
                  <div>
                    <p className="text-sm">
                      <span className="font-medium">Lisa Park</span> logged 2 hours of work
                    </p>
                    <p className="text-xs text-muted-foreground">2 hours ago</p>
                  </div>
                </div>
                <div className="flex gap-3 p-3 border rounded-lg">
                  <MessageSquare className="w-4 h-4 mt-1 text-green-600" />
                  <div>
                    <p className="text-sm">
                      <span className="font-medium">Sarah Johnson</span> added a comment
                    </p>
                    <p className="text-xs text-muted-foreground">1 day ago</p>
                  </div>
                </div>
                <div className="flex gap-3 p-3 border rounded-lg">
                  <Edit className="w-4 h-4 mt-1 text-purple-600" />
                  <div>
                    <p className="text-sm">
                      <span className="font-medium">Mike Chen</span> updated task status to In Progress
                    </p>
                    <p className="text-xs text-muted-foreground">2 days ago</p>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  )
}
