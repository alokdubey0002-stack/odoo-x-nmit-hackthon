"use client"

import type React from "react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Calendar, MessageSquare, Paperclip, Flag, Clock } from "lucide-react"

interface Task {
  id: string
  title: string
  description: string
  status: "Todo" | "In Progress" | "Review" | "Done"
  priority: "Low" | "Medium" | "High" | "Critical"
  assignee: string
  assigneeAvatar: string
  reporter: string
  projectId: string
  projectName: string
  dueDate: string
  createdDate: string
  updatedDate: string
  tags: string[]
  comments: number
  attachments: number
  estimatedHours?: number
  loggedHours?: number
}

interface KanbanBoardProps {
  tasks: Task[]
  onTaskClick: (task: Task) => void
  onTaskUpdate: (taskId: string, updates: Partial<Task>) => void
  getPriorityColor: (priority: string) => string
  getStatusColor: (status: string) => string
}

export function KanbanBoard({ tasks, onTaskClick, onTaskUpdate, getPriorityColor }: KanbanBoardProps) {
  const columns = [
    { id: "Todo", title: "Todo", status: "Todo" as const },
    { id: "In Progress", title: "In Progress", status: "In Progress" as const },
    { id: "Review", title: "Review", status: "Review" as const },
    { id: "Done", title: "Done", status: "Done" as const },
  ]

  const getColumnTasks = (status: Task["status"]) => {
    return tasks.filter((task) => task.status === status)
  }

  const handleDragStart = (e: React.DragEvent, task: Task) => {
    e.dataTransfer.setData("text/plain", task.id)
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
  }

  const handleDrop = (e: React.DragEvent, newStatus: Task["status"]) => {
    e.preventDefault()
    const taskId = e.dataTransfer.getData("text/plain")
    onTaskUpdate(taskId, { status: newStatus })
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {columns.map((column) => {
        const columnTasks = getColumnTasks(column.status)
        return (
          <div key={column.id} className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-lg">{column.title}</h3>
              <Badge variant="secondary">{columnTasks.length}</Badge>
            </div>

            <div
              className="min-h-[500px] space-y-3 p-2 rounded-lg border-2 border-dashed border-gray-200 dark:border-gray-700"
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, column.status)}
            >
              {columnTasks.map((task) => (
                <Card
                  key={task.id}
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  draggable
                  onDragStart={(e) => handleDragStart(e, task)}
                  onClick={() => onTaskClick(task)}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <CardTitle className="text-sm font-medium leading-tight">{task.title}</CardTitle>
                      <Badge variant="outline" className={`${getPriorityColor(task.priority)} ml-2 flex-shrink-0`}>
                        <Flag className="w-3 h-3 mr-1" />
                        {task.priority}
                      </Badge>
                    </div>
                  </CardHeader>

                  <CardContent className="pt-0">
                    <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{task.description}</p>

                    {/* Tags */}
                    {task.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-3">
                        {task.tags.slice(0, 2).map((tag) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {task.tags.length > 2 && (
                          <Badge variant="secondary" className="text-xs">
                            +{task.tags.length - 2}
                          </Badge>
                        )}
                      </div>
                    )}

                    {/* Task Meta */}
                    <div className="space-y-2 text-xs text-muted-foreground">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          <span>{task.dueDate}</span>
                        </div>
                        {task.estimatedHours && (
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>
                              {task.loggedHours || 0}h/{task.estimatedHours}h
                            </span>
                          </div>
                        )}
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1">
                          <Avatar className="w-4 h-4">
                            <AvatarFallback className="text-xs">{task.assigneeAvatar}</AvatarFallback>
                          </Avatar>
                          <span className="truncate">{task.assignee}</span>
                        </div>

                        <div className="flex items-center gap-2">
                          {task.comments > 0 && (
                            <div className="flex items-center gap-1">
                              <MessageSquare className="w-3 h-3" />
                              <span>{task.comments}</span>
                            </div>
                          )}
                          {task.attachments > 0 && (
                            <div className="flex items-center gap-1">
                              <Paperclip className="w-3 h-3" />
                              <span>{task.attachments}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Progress Bar for estimated hours */}
                    {task.estimatedHours && task.loggedHours !== undefined && (
                      <div className="mt-3">
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1">
                          <div
                            className="bg-blue-600 h-1 rounded-full transition-all"
                            style={{
                              width: `${Math.min((task.loggedHours / task.estimatedHours) * 100, 100)}%`,
                            }}
                          />
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}

              {columnTasks.length === 0 && (
                <div className="flex items-center justify-center h-32 text-muted-foreground">
                  <p className="text-sm">Drop tasks here</p>
                </div>
              )}
            </div>
          </div>
        )
      })}
    </div>
  )
}
