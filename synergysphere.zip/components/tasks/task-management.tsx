"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Plus,
  Search,
  Calendar,
  User,
  Clock,
  Flag,
  MessageSquare,
  Paperclip,
  MoreHorizontal,
  ArrowLeft,
} from "lucide-react"
import { TaskCreationModal } from "./task-creation-modal"
import { TaskDetailModal } from "./task-detail-modal"
import { KanbanBoard } from "./kanban-board"

interface Task {
  id: string
  title: string
  description: string
  status: "Todo" | "In Progress" | "Review" | "Done"
  priority: "Low" | "Medium" | "High" | "Critical"
  assignee: string
  assigneeAvatar: string
  reporter: string
  projectId: string
  projectName: string
  dueDate: string
  createdDate: string
  updatedDate: string
  tags: string[]
  comments: number
  attachments: number
  estimatedHours?: number
  loggedHours?: number
}

interface TaskManagementProps {
  projectId?: string
  projectName?: string
  onBack?: () => void
}

export function TaskManagement({ projectId, projectName, onBack }: TaskManagementProps) {
  const [viewMode, setViewMode] = useState<"kanban" | "list">("kanban")
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [priorityFilter, setPriorityFilter] = useState<string>("all")
  const [assigneeFilter, setAssigneeFilter] = useState<string>("all")
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [selectedTask, setSelectedTask] = useState<Task | null>(null)

  const [tasks, setTasks] = useState<Task[]>([
    {
      id: "1",
      title: "Design user authentication flow",
      description: "Create wireframes and mockups for the login and registration process",
      status: "In Progress",
      priority: "High",
      assignee: "Lisa Park",
      assigneeAvatar: "LP",
      reporter: "Sarah Johnson",
      projectId: "1",
      projectName: "Website Redesign",
      dueDate: "2024-01-25",
      createdDate: "2024-01-15",
      updatedDate: "2024-01-20",
      tags: ["design", "ui/ux", "authentication"],
      comments: 3,
      attachments: 2,
      estimatedHours: 8,
      loggedHours: 5,
    },
    {
      id: "2",
      title: "Implement user registration API",
      description: "Build backend API endpoints for user registration with validation",
      status: "Todo",
      priority: "Critical",
      assignee: "Mike Chen",
      assigneeAvatar: "MC",
      reporter: "Sarah Johnson",
      projectId: "1",
      projectName: "Website Redesign",
      dueDate: "2024-01-30",
      createdDate: "2024-01-16",
      updatedDate: "2024-01-16",
      tags: ["backend", "api", "authentication"],
      comments: 1,
      attachments: 0,
      estimatedHours: 12,
      loggedHours: 0,
    },
    {
      id: "3",
      title: "Set up database schema",
      description: "Design and implement the database structure for user management",
      status: "Done",
      priority: "High",
      assignee: "Mike Chen",
      assigneeAvatar: "MC",
      reporter: "Sarah Johnson",
      projectId: "1",
      projectName: "Website Redesign",
      dueDate: "2024-01-20",
      createdDate: "2024-01-10",
      updatedDate: "2024-01-18",
      tags: ["database", "backend"],
      comments: 2,
      attachments: 1,
      estimatedHours: 6,
      loggedHours: 6,
    },
    {
      id: "4",
      title: "Create responsive navigation component",
      description: "Build a mobile-friendly navigation component with dropdown menus",
      status: "Review",
      priority: "Medium",
      assignee: "Lisa Park",
      assigneeAvatar: "LP",
      reporter: "David Kim",
      projectId: "1",
      projectName: "Website Redesign",
      dueDate: "2024-01-28",
      createdDate: "2024-01-12",
      updatedDate: "2024-01-22",
      tags: ["frontend", "component", "responsive"],
      comments: 4,
      attachments: 3,
      estimatedHours: 10,
      loggedHours: 9,
    },
    {
      id: "5",
      title: "Write unit tests for authentication",
      description: "Comprehensive test coverage for all authentication-related functions",
      status: "Todo",
      priority: "Medium",
      assignee: "David Kim",
      assigneeAvatar: "DK",
      reporter: "Mike Chen",
      projectId: "1",
      projectName: "Website Redesign",
      dueDate: "2024-02-05",
      createdDate: "2024-01-18",
      updatedDate: "2024-01-18",
      tags: ["testing", "quality-assurance"],
      comments: 0,
      attachments: 0,
      estimatedHours: 8,
      loggedHours: 0,
    },
    {
      id: "6",
      title: "Mobile app wireframes",
      description: "Create detailed wireframes for all mobile app screens",
      status: "In Progress",
      priority: "High",
      assignee: "Lisa Park",
      assigneeAvatar: "LP",
      reporter: "Sarah Johnson",
      projectId: "2",
      projectName: "Mobile App Development",
      dueDate: "2024-02-10",
      createdDate: "2024-01-20",
      updatedDate: "2024-01-23",
      tags: ["mobile", "wireframes", "design"],
      comments: 2,
      attachments: 5,
      estimatedHours: 16,
      loggedHours: 8,
    },
  ])

  const filteredTasks = tasks.filter((task) => {
    const matchesSearch =
      task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))

    const matchesStatus = statusFilter === "all" || task.status === statusFilter
    const matchesPriority = priorityFilter === "all" || task.priority === priorityFilter
    const matchesAssignee = assigneeFilter === "all" || task.assignee === assigneeFilter
    const matchesProject = !projectId || task.projectId === projectId

    return matchesSearch && matchesStatus && matchesPriority && matchesAssignee && matchesProject
  })

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "Critical":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400"
      case "High":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400"
      case "Medium":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400"
      case "Low":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Todo":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
      case "In Progress":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400"
      case "Review":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-400"
      case "Done":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400"
    }
  }

  const uniqueAssignees = Array.from(new Set(tasks.map((task) => task.assignee)))

  const handleCreateTask = (taskData: Omit<Task, "id" | "createdDate" | "updatedDate">) => {
    const newTask: Task = {
      ...taskData,
      id: Date.now().toString(),
      createdDate: new Date().toISOString().split("T")[0],
      updatedDate: new Date().toISOString().split("T")[0],
    }
    setTasks([...tasks, newTask])
    setShowCreateModal(false)
  }

  const handleUpdateTask = (taskId: string, updates: Partial<Task>) => {
    setTasks(
      tasks.map((task) =>
        task.id === taskId
          ? {
              ...task,
              ...updates,
              updatedDate: new Date().toISOString().split("T")[0],
            }
          : task,
      ),
    )
  }

  const taskStats = {
    total: filteredTasks.length,
    todo: filteredTasks.filter((t) => t.status === "Todo").length,
    inProgress: filteredTasks.filter((t) => t.status === "In Progress").length,
    review: filteredTasks.filter((t) => t.status === "Review").length,
    done: filteredTasks.filter((t) => t.status === "Done").length,
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {onBack && (
                <Button variant="ghost" size="sm" onClick={onBack}>
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              )}
              <div>
                <h1 className="text-2xl font-bold">{projectName ? `${projectName} - Tasks` : "Task Management"}</h1>
                <p className="text-muted-foreground">Organize and track your team's work</p>
              </div>
            </div>
            <Button onClick={() => setShowCreateModal(true)}>
              <Plus className="w-4 h-4 mr-2" />
              New Task
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6">
            <Card>
              <CardContent className="p-4">
                <div className="text-center">
                  <p className="text-2xl font-bold">{taskStats.total}</p>
                  <p className="text-sm text-muted-foreground">Total Tasks</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-gray-600">{taskStats.todo}</p>
                  <p className="text-sm text-muted-foreground">Todo</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-blue-600">{taskStats.inProgress}</p>
                  <p className="text-sm text-muted-foreground">In Progress</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-purple-600">{taskStats.review}</p>
                  <p className="text-sm text-muted-foreground">Review</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-green-600">{taskStats.done}</p>
                  <p className="text-sm text-muted-foreground">Done</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        {/* Filters and Search */}
        <div className="flex flex-col lg:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search tasks, descriptions, or tags..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Todo">Todo</SelectItem>
                <SelectItem value="In Progress">In Progress</SelectItem>
                <SelectItem value="Review">Review</SelectItem>
                <SelectItem value="Done">Done</SelectItem>
              </SelectContent>
            </Select>

            <Select value={priorityFilter} onValueChange={setPriorityFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priority</SelectItem>
                <SelectItem value="Critical">Critical</SelectItem>
                <SelectItem value="High">High</SelectItem>
                <SelectItem value="Medium">Medium</SelectItem>
                <SelectItem value="Low">Low</SelectItem>
              </SelectContent>
            </Select>

            <Select value={assigneeFilter} onValueChange={setAssigneeFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Assignee" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Assignees</SelectItem>
                {uniqueAssignees.map((assignee) => (
                  <SelectItem key={assignee} value={assignee}>
                    {assignee}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* View Toggle */}
        <Tabs value={viewMode} onValueChange={(value: any) => setViewMode(value)} className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="kanban">Kanban Board</TabsTrigger>
            <TabsTrigger value="list">List View</TabsTrigger>
          </TabsList>

          <TabsContent value="kanban">
            <KanbanBoard
              tasks={filteredTasks}
              onTaskClick={setSelectedTask}
              onTaskUpdate={handleUpdateTask}
              getPriorityColor={getPriorityColor}
              getStatusColor={getStatusColor}
            />
          </TabsContent>

          <TabsContent value="list">
            <div className="space-y-4">
              {filteredTasks.map((task) => (
                <Card key={task.id} className="hover:shadow-md transition-shadow cursor-pointer">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3
                            className="font-semibold hover:text-blue-600 cursor-pointer"
                            onClick={() => setSelectedTask(task)}
                          >
                            {task.title}
                          </h3>
                          <Badge className={getStatusColor(task.status)}>{task.status}</Badge>
                          <Badge variant="outline" className={getPriorityColor(task.priority)}>
                            <Flag className="w-3 h-3 mr-1" />
                            {task.priority}
                          </Badge>
                        </div>

                        <p className="text-muted-foreground mb-3">{task.description}</p>

                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <User className="w-4 h-4" />
                            <Avatar className="w-5 h-5">
                              <AvatarFallback className="text-xs">{task.assigneeAvatar}</AvatarFallback>
                            </Avatar>
                            <span>{task.assignee}</span>
                          </div>

                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            <span>Due {task.dueDate}</span>
                          </div>

                          {task.estimatedHours && (
                            <div className="flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              <span>
                                {task.loggedHours || 0}h / {task.estimatedHours}h
                              </span>
                            </div>
                          )}

                          <div className="flex items-center gap-3">
                            {task.comments > 0 && (
                              <div className="flex items-center gap-1">
                                <MessageSquare className="w-4 h-4" />
                                <span>{task.comments}</span>
                              </div>
                            )}
                            {task.attachments > 0 && (
                              <div className="flex items-center gap-1">
                                <Paperclip className="w-4 h-4" />
                                <span>{task.attachments}</span>
                              </div>
                            )}
                          </div>
                        </div>

                        {task.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-3">
                            {task.tags.map((tag) => (
                              <Badge key={tag} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>

                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {filteredTasks.length === 0 && (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Search className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">No tasks found</h3>
                  <p className="text-muted-foreground mb-4">Try adjusting your search or filters.</p>
                  <Button onClick={() => setShowCreateModal(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Create New Task
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <TaskCreationModal
        open={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onCreateTask={handleCreateTask}
        projectId={projectId}
        projectName={projectName}
      />

      {selectedTask && (
        <TaskDetailModal
          task={selectedTask}
          open={!!selectedTask}
          onClose={() => setSelectedTask(null)}
          onUpdateTask={handleUpdateTask}
        />
      )}
    </div>
  )
}
