"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Bell, Check, X, MessageSquare, AlertTriangle, CheckCircle, Clock, Users, FileText } from "lucide-react"

interface Notification {
  id: string
  type: "mention" | "assignment" | "deadline" | "team" | "project" | "system"
  title: string
  message: string
  timestamp: string
  read: boolean
  priority: "low" | "medium" | "high"
  actionUrl?: string
  avatar?: string
  author?: string
}

interface NotificationCenterProps {
  isOpen: boolean
  onClose: () => void
  notifications: Notification[]
  onMarkAsRead: (id: string) => void
  onMarkAllAsRead: () => void
  onDeleteNotification: (id: string) => void
}

const mockNotifications: Notification[] = [
  {
    id: "1",
    type: "mention",
    title: "You were mentioned",
    message: "Alice Johnson mentioned you in Website Redesign project discussion",
    timestamp: "2 minutes ago",
    read: false,
    priority: "high",
    author: "Alice Johnson",
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: "2",
    type: "assignment",
    title: "New task assigned",
    message: "You have been assigned to 'Update homepage design' in Website Redesign",
    timestamp: "15 minutes ago",
    read: false,
    priority: "medium",
    author: "Bob Smith",
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: "3",
    type: "deadline",
    title: "Deadline approaching",
    message: "Marketing Campaign project is due in 2 days",
    timestamp: "1 hour ago",
    read: false,
    priority: "high",
  },
  {
    id: "4",
    type: "team",
    title: "Team member joined",
    message: "David Kim joined the Mobile App Development project",
    timestamp: "3 hours ago",
    read: true,
    priority: "low",
    author: "David Kim",
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: "5",
    type: "project",
    title: "Project status updated",
    message: "User Research Study has been marked as completed",
    timestamp: "1 day ago",
    read: true,
    priority: "medium",
  },
  {
    id: "6",
    type: "system",
    title: "System maintenance",
    message: "Scheduled maintenance will occur tonight from 2-4 AM EST",
    timestamp: "2 days ago",
    read: true,
    priority: "low",
  },
]

export function NotificationCenter({
  isOpen,
  onClose,
  notifications = mockNotifications,
  onMarkAsRead,
  onMarkAllAsRead,
  onDeleteNotification,
}: NotificationCenterProps) {
  const [notificationSettings, setNotificationSettings] = useState({
    mentions: true,
    assignments: true,
    deadlines: true,
    teamUpdates: true,
    projectUpdates: true,
    systemAlerts: false,
    emailNotifications: true,
    pushNotifications: true,
  })

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "mention":
        return <MessageSquare className="h-4 w-4 text-blue-500" />
      case "assignment":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "deadline":
        return <Clock className="h-4 w-4 text-red-500" />
      case "team":
        return <Users className="h-4 w-4 text-purple-500" />
      case "project":
        return <FileText className="h-4 w-4 text-orange-500" />
      case "system":
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      default:
        return <Bell className="h-4 w-4 text-gray-500" />
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "border-l-red-500"
      case "medium":
        return "border-l-yellow-500"
      case "low":
        return "border-l-green-500"
      default:
        return "border-l-gray-300"
    }
  }

  const unreadCount = notifications.filter((n) => !n.read).length
  const unreadNotifications = notifications.filter((n) => !n.read)
  const readNotifications = notifications.filter((n) => n.read)

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 bg-black/50" onClick={onClose}>
      <div
        className="fixed right-0 top-0 h-full w-96 bg-background border-l shadow-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex flex-col h-full">
          <div className="p-4 border-b">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                <h2 className="text-lg font-semibold">Notifications</h2>
                {unreadCount > 0 && (
                  <Badge variant="destructive" className="h-5 w-5 p-0 flex items-center justify-center text-xs">
                    {unreadCount}
                  </Badge>
                )}
              </div>
              <Button variant="ghost" size="sm" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={onMarkAllAsRead} disabled={unreadCount === 0}>
                <Check className="h-4 w-4 mr-1" />
                Mark all read
              </Button>
            </div>
          </div>

          <Tabs defaultValue="all" className="flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-3 mx-4 mt-4">
              <TabsTrigger value="all">All ({notifications.length})</TabsTrigger>
              <TabsTrigger value="unread">Unread ({unreadCount})</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="flex-1 mt-4">
              <ScrollArea className="h-full px-4">
                <div className="space-y-2">
                  {notifications.map((notification) => (
                    <Card
                      key={notification.id}
                      className={`cursor-pointer transition-colors hover:bg-muted/50 border-l-4 ${getPriorityColor(
                        notification.priority,
                      )} ${!notification.read ? "bg-muted/30" : ""}`}
                      onClick={() => onMarkAsRead(notification.id)}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className="flex-shrink-0 mt-1">{getNotificationIcon(notification.type)}</div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between mb-1">
                              <h4 className="text-sm font-medium truncate">{notification.title}</h4>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100"
                                onClick={(e) => {
                                  e.stopPropagation()
                                  onDeleteNotification(notification.id)
                                }}
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            </div>
                            <p className="text-sm text-muted-foreground mb-2">{notification.message}</p>
                            <div className="flex items-center justify-between">
                              <span className="text-xs text-muted-foreground">{notification.timestamp}</span>
                              {!notification.read && <div className="w-2 h-2 bg-blue-500 rounded-full" />}
                            </div>
                            {notification.author && (
                              <div className="flex items-center gap-2 mt-2">
                                <Avatar className="h-6 w-6">
                                  <AvatarImage src={notification.avatar || "/placeholder.svg"} />
                                  <AvatarFallback className="text-xs">
                                    {notification.author
                                      .split(" ")
                                      .map((n) => n[0])
                                      .join("")}
                                  </AvatarFallback>
                                </Avatar>
                                <span className="text-xs text-muted-foreground">{notification.author}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="unread" className="flex-1 mt-4">
              <ScrollArea className="h-full px-4">
                <div className="space-y-2">
                  {unreadNotifications.length === 0 ? (
                    <div className="text-center py-8">
                      <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold mb-2">All caught up!</h3>
                      <p className="text-muted-foreground">No unread notifications</p>
                    </div>
                  ) : (
                    unreadNotifications.map((notification) => (
                      <Card
                        key={notification.id}
                        className={`cursor-pointer transition-colors hover:bg-muted/50 border-l-4 ${getPriorityColor(
                          notification.priority,
                        )} bg-muted/30`}
                        onClick={() => onMarkAsRead(notification.id)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start gap-3">
                            <div className="flex-shrink-0 mt-1">{getNotificationIcon(notification.type)}</div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between mb-1">
                                <h4 className="text-sm font-medium truncate">{notification.title}</h4>
                                <div className="w-2 h-2 bg-blue-500 rounded-full" />
                              </div>
                              <p className="text-sm text-muted-foreground mb-2">{notification.message}</p>
                              <span className="text-xs text-muted-foreground">{notification.timestamp}</span>
                              {notification.author && (
                                <div className="flex items-center gap-2 mt-2">
                                  <Avatar className="h-6 w-6">
                                    <AvatarImage src={notification.avatar || "/placeholder.svg"} />
                                    <AvatarFallback className="text-xs">
                                      {notification.author
                                        .split(" ")
                                        .map((n) => n[0])
                                        .join("")}
                                    </AvatarFallback>
                                  </Avatar>
                                  <span className="text-xs text-muted-foreground">{notification.author}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="settings" className="flex-1 mt-4">
              <ScrollArea className="h-full px-4">
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Notification Types</CardTitle>
                      <CardDescription>Choose which notifications you want to receive</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="mentions" className="flex items-center gap-2">
                          <MessageSquare className="h-4 w-4 text-blue-500" />
                          Mentions
                        </Label>
                        <Switch
                          id="mentions"
                          checked={notificationSettings.mentions}
                          onCheckedChange={(checked) =>
                            setNotificationSettings({ ...notificationSettings, mentions: checked })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="assignments" className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Task Assignments
                        </Label>
                        <Switch
                          id="assignments"
                          checked={notificationSettings.assignments}
                          onCheckedChange={(checked) =>
                            setNotificationSettings({ ...notificationSettings, assignments: checked })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="deadlines" className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-red-500" />
                          Deadlines
                        </Label>
                        <Switch
                          id="deadlines"
                          checked={notificationSettings.deadlines}
                          onCheckedChange={(checked) =>
                            setNotificationSettings({ ...notificationSettings, deadlines: checked })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="teamUpdates" className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-purple-500" />
                          Team Updates
                        </Label>
                        <Switch
                          id="teamUpdates"
                          checked={notificationSettings.teamUpdates}
                          onCheckedChange={(checked) =>
                            setNotificationSettings({ ...notificationSettings, teamUpdates: checked })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="projectUpdates" className="flex items-center gap-2">
                          <FileText className="h-4 w-4 text-orange-500" />
                          Project Updates
                        </Label>
                        <Switch
                          id="projectUpdates"
                          checked={notificationSettings.projectUpdates}
                          onCheckedChange={(checked) =>
                            setNotificationSettings({ ...notificationSettings, projectUpdates: checked })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="systemAlerts" className="flex items-center gap-2">
                          <AlertTriangle className="h-4 w-4 text-yellow-500" />
                          System Alerts
                        </Label>
                        <Switch
                          id="systemAlerts"
                          checked={notificationSettings.systemAlerts}
                          onCheckedChange={(checked) =>
                            setNotificationSettings({ ...notificationSettings, systemAlerts: checked })
                          }
                        />
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-base">Delivery Methods</CardTitle>
                      <CardDescription>How you want to receive notifications</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="emailNotifications">Email Notifications</Label>
                        <Switch
                          id="emailNotifications"
                          checked={notificationSettings.emailNotifications}
                          onCheckedChange={(checked) =>
                            setNotificationSettings({ ...notificationSettings, emailNotifications: checked })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="pushNotifications">Push Notifications</Label>
                        <Switch
                          id="pushNotifications"
                          checked={notificationSettings.pushNotifications}
                          onCheckedChange={(checked) =>
                            setNotificationSettings({ ...notificationSettings, pushNotifications: checked })
                          }
                        />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
