"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { X, Bell, CheckCircle, AlertTriangle, Info, MessageSquare } from "lucide-react"

interface ToastNotification {
  id: string
  type: "success" | "error" | "warning" | "info" | "mention"
  title: string
  message: string
  duration?: number
  avatar?: string
  author?: string
}

interface ToastNotificationsProps {
  notifications: ToastNotification[]
  onDismiss: (id: string) => void
}

export function ToastNotifications({ notifications, onDismiss }: ToastNotificationsProps) {
  const [visibleNotifications, setVisibleNotifications] = useState<ToastNotification[]>([])

  useEffect(() => {
    setVisibleNotifications(notifications)

    // Auto-dismiss notifications after their duration
    notifications.forEach((notification) => {
      if (notification.duration && notification.duration > 0) {
        setTimeout(() => {
          onDismiss(notification.id)
        }, notification.duration)
      }
    })
  }, [notifications, onDismiss])

  const getToastIcon = (type: string) => {
    switch (type) {
      case "success":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "error":
        return <AlertTriangle className="h-5 w-5 text-red-500" />
      case "warning":
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />
      case "info":
        return <Info className="h-5 w-5 text-blue-500" />
      case "mention":
        return <MessageSquare className="h-5 w-5 text-purple-500" />
      default:
        return <Bell className="h-5 w-5 text-gray-500" />
    }
  }

  const getToastStyles = (type: string) => {
    switch (type) {
      case "success":
        return "border-l-4 border-l-green-500 bg-green-50 dark:bg-green-900/20"
      case "error":
        return "border-l-4 border-l-red-500 bg-red-50 dark:bg-red-900/20"
      case "warning":
        return "border-l-4 border-l-yellow-500 bg-yellow-50 dark:bg-yellow-900/20"
      case "info":
        return "border-l-4 border-l-blue-500 bg-blue-50 dark:bg-blue-900/20"
      case "mention":
        return "border-l-4 border-l-purple-500 bg-purple-50 dark:bg-purple-900/20"
      default:
        return "border-l-4 border-l-gray-500 bg-gray-50 dark:bg-gray-900/20"
    }
  }

  if (visibleNotifications.length === 0) return null

  return (
    <div className="fixed top-4 right-4 z-50 space-y-2 max-w-sm">
      {visibleNotifications.map((notification) => (
        <Card
          key={notification.id}
          className={`shadow-lg animate-in slide-in-from-right-full duration-300 ${getToastStyles(notification.type)}`}
        >
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="flex-shrink-0 mt-0.5">{getToastIcon(notification.type)}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="text-sm font-medium truncate">{notification.title}</h4>
                  <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => onDismiss(notification.id)}>
                    <X className="h-3 w-3" />
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground">{notification.message}</p>
                {notification.author && (
                  <div className="flex items-center gap-2 mt-2">
                    <Avatar className="h-6 w-6">
                      <AvatarImage src={notification.avatar || "/placeholder.svg"} />
                      <AvatarFallback className="text-xs">
                        {notification.author
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-xs text-muted-foreground">{notification.author}</span>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
