"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Send, Search, Hash, Users, Phone, Video, MoreHorizontal, Smile, Paperclip, AtSign } from "lucide-react"

interface Message {
  id: string
  content: string
  author: string
  avatar: string
  timestamp: string
  type: "text" | "file" | "system"
  reactions?: { emoji: string; count: number; users: string[] }[]
  mentions?: string[]
  threadId?: string
}

interface Channel {
  id: string
  name: string
  type: "channel" | "dm" | "thread"
  participants: string[]
  unreadCount: number
  lastMessage?: Message
}

const mockChannels: Channel[] = [
  {
    id: "1",
    name: "general",
    type: "channel",
    participants: ["Alice Johnson", "Bob Smith", "Carol Davis"],
    unreadCount: 3,
    lastMessage: {
      id: "1",
      content: "Great progress on the new features!",
      author: "Alice Johnson",
      avatar: "/placeholder.svg?height=32&width=32",
      timestamp: "2 min ago",
      type: "text",
    },
  },
  {
    id: "2",
    name: "project-alpha",
    type: "channel",
    participants: ["Alice Johnson", "Bob Smith"],
    unreadCount: 1,
    lastMessage: {
      id: "2",
      content: "Updated the design mockups",
      author: "Bob Smith",
      avatar: "/placeholder.svg?height=32&width=32",
      timestamp: "5 min ago",
      type: "text",
    },
  },
  {
    id: "3",
    name: "Carol Davis",
    type: "dm",
    participants: ["Carol Davis"],
    unreadCount: 0,
    lastMessage: {
      id: "3",
      content: "Thanks for the feedback!",
      author: "Carol Davis",
      avatar: "/placeholder.svg?height=32&width=32",
      timestamp: "1 hour ago",
      type: "text",
    },
  },
]

const mockMessages: Message[] = [
  {
    id: "1",
    content: "Welcome to the project! Let's get started with the initial planning.",
    author: "Alice Johnson",
    avatar: "/placeholder.svg?height=32&width=32",
    timestamp: "10:30 AM",
    type: "text",
    reactions: [{ emoji: "👍", count: 2, users: ["Bob Smith", "Carol Davis"] }],
  },
  {
    id: "2",
    content: "I've uploaded the latest design files to the shared folder.",
    author: "Bob Smith",
    avatar: "/placeholder.svg?height=32&width=32",
    timestamp: "10:45 AM",
    type: "file",
  },
  {
    id: "3",
    content: "@Alice Johnson Could you review the wireframes when you have a moment?",
    author: "Carol Davis",
    avatar: "/placeholder.svg?height=32&width=32",
    timestamp: "11:15 AM",
    type: "text",
    mentions: ["Alice Johnson"],
  },
  {
    id: "4",
    content: "I'll take a look this afternoon and provide feedback.",
    author: "Alice Johnson",
    avatar: "/placeholder.svg?height=32&width=32",
    timestamp: "11:20 AM",
    type: "text",
  },
]

export function CommunicationHub() {
  const [selectedChannel, setSelectedChannel] = useState<Channel>(mockChannels[0])
  const [messages, setMessages] = useState<Message[]>(mockMessages)
  const [newMessage, setNewMessage] = useState("")
  const [searchQuery, setSearchQuery] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = () => {
    if (!newMessage.trim()) return

    const message: Message = {
      id: Date.now().toString(),
      content: newMessage,
      author: "You",
      avatar: "/placeholder.svg?height=32&width=32",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      type: "text",
    }

    setMessages([...messages, message])
    setNewMessage("")
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const filteredChannels = mockChannels.filter((channel) =>
    channel.name.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="flex h-full bg-background">
      {/* Sidebar */}
      <div className="w-80 border-r bg-muted/30">
        <div className="p-4 border-b">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Communications</h2>
            <Button size="sm" variant="outline">
              <Users className="h-4 w-4 mr-2" />
              Invite
            </Button>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <Tabs defaultValue="channels" className="flex-1">
          <TabsList className="grid w-full grid-cols-2 mx-4 mt-4">
            <TabsTrigger value="channels">Channels</TabsTrigger>
            <TabsTrigger value="direct">Direct</TabsTrigger>
          </TabsList>

          <TabsContent value="channels" className="mt-4">
            <ScrollArea className="h-[calc(100vh-200px)]">
              <div className="px-4 space-y-2">
                {filteredChannels
                  .filter((channel) => channel.type === "channel")
                  .map((channel) => (
                    <Card
                      key={channel.id}
                      className={`cursor-pointer transition-colors hover:bg-muted/50 ${
                        selectedChannel.id === channel.id ? "bg-muted border-primary" : ""
                      }`}
                      onClick={() => setSelectedChannel(channel)}
                    >
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <Hash className="h-4 w-4 text-muted-foreground" />
                            <div>
                              <p className="font-medium">{channel.name}</p>
                              <p className="text-sm text-muted-foreground truncate">{channel.lastMessage?.content}</p>
                            </div>
                          </div>
                          <div className="flex flex-col items-end space-y-1">
                            {channel.unreadCount > 0 && (
                              <Badge
                                variant="destructive"
                                className="h-5 w-5 p-0 flex items-center justify-center text-xs"
                              >
                                {channel.unreadCount}
                              </Badge>
                            )}
                            <span className="text-xs text-muted-foreground">{channel.lastMessage?.timestamp}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="direct" className="mt-4">
            <ScrollArea className="h-[calc(100vh-200px)]">
              <div className="px-4 space-y-2">
                {filteredChannels
                  .filter((channel) => channel.type === "dm")
                  .map((channel) => (
                    <Card
                      key={channel.id}
                      className={`cursor-pointer transition-colors hover:bg-muted/50 ${
                        selectedChannel.id === channel.id ? "bg-muted border-primary" : ""
                      }`}
                      onClick={() => setSelectedChannel(channel)}
                    >
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <Avatar className="h-8 w-8">
                              <AvatarImage src="/placeholder.svg?height=32&width=32" />
                              <AvatarFallback>
                                {channel.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{channel.name}</p>
                              <p className="text-sm text-muted-foreground truncate">{channel.lastMessage?.content}</p>
                            </div>
                          </div>
                          <div className="flex flex-col items-end space-y-1">
                            {channel.unreadCount > 0 && (
                              <Badge
                                variant="destructive"
                                className="h-5 w-5 p-0 flex items-center justify-center text-xs"
                              >
                                {channel.unreadCount}
                              </Badge>
                            )}
                            <span className="text-xs text-muted-foreground">{channel.lastMessage?.timestamp}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Chat Header */}
        <div className="p-4 border-b bg-background">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {selectedChannel.type === "channel" ? (
                <Hash className="h-5 w-5 text-muted-foreground" />
              ) : (
                <Avatar className="h-8 w-8">
                  <AvatarImage src="/placeholder.svg?height=32&width=32" />
                  <AvatarFallback>
                    {selectedChannel.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
              )}
              <div>
                <h3 className="font-semibold">{selectedChannel.name}</h3>
                <p className="text-sm text-muted-foreground">
                  {selectedChannel.participants.length} member{selectedChannel.participants.length !== 1 ? "s" : ""}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button size="sm" variant="ghost">
                <Phone className="h-4 w-4" />
              </Button>
              <Button size="sm" variant="ghost">
                <Video className="h-4 w-4" />
              </Button>
              <Button size="sm" variant="ghost">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Messages */}
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div key={message.id} className="flex items-start space-x-3">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={message.avatar || "/placeholder.svg"} />
                  <AvatarFallback>
                    {message.author
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="font-medium text-sm">{message.author}</span>
                    <span className="text-xs text-muted-foreground">{message.timestamp}</span>
                  </div>
                  <div className="bg-muted/50 rounded-lg p-3 max-w-2xl">
                    <p className="text-sm leading-relaxed">
                      {message.content.split(" ").map((word, index) => {
                        if (word.startsWith("@")) {
                          return (
                            <span key={index} className="text-primary font-medium">
                              {word}{" "}
                            </span>
                          )
                        }
                        return word + " "
                      })}
                    </p>
                    {message.type === "file" && (
                      <div className="mt-2 p-2 bg-background rounded border">
                        <div className="flex items-center space-x-2">
                          <Paperclip className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">design-files.zip</span>
                        </div>
                      </div>
                    )}
                  </div>
                  {message.reactions && (
                    <div className="flex items-center space-x-1 mt-2">
                      {message.reactions.map((reaction, index) => (
                        <Button key={index} size="sm" variant="outline" className="h-6 px-2 text-xs bg-transparent">
                          {reaction.emoji} {reaction.count}
                        </Button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* Message Input */}
        <div className="p-4 border-t bg-background">
          <div className="flex items-end space-x-2">
            <div className="flex-1 relative">
              <Input
                placeholder={`Message ${selectedChannel.name}...`}
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                className="pr-20"
              />
              <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center space-x-1">
                <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                  <Paperclip className="h-3 w-3" />
                </Button>
                <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                  <AtSign className="h-3 w-3" />
                </Button>
                <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                  <Smile className="h-3 w-3" />
                </Button>
              </div>
            </div>
            <Button onClick={handleSendMessage} disabled={!newMessage.trim()}>
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
